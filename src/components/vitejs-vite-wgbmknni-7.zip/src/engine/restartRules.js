// Restart rules shared by the seeded engine (matchSimEngine.js), the default
// Match Centre chain (MatchCentre.jsx + matchPresentation.js) and the audit in
// matchRules.js. Pure data and pure functions, no imports, so nothing here can
// create a circular dependency.
//
//   6. KICK-IN       A behind is followed by a kick-in from the goal square by a
//                    defender. It is an unpressured kick (or a short play-on
//                    run) that must gain real ground; it is never a stoppage,
//                    so it earns no hit-out, clearance or ball-up free kick.
//   7. OUT ON THE    A kick that leaves the ground untouched, and a shot that
//      FULL          misses everything, is a free kick to the other side taken
//                    where the ball crossed the boundary. The ball never goes
//                    back to where the kick was taken from.
//   8. NO SIDEWAYS   Outside the forward half a disposal that gains almost no
//      CHAINS        ground may not be followed by more than MAX_FLAT_CHAIN
//                    others in a row. After that the carrier must break the
//                    chain forward or run.

// ---- 6. KICK-IN -------------------------------------------------------------
export const KICK_IN = Object.freeze({
  MIN_FORWARD_METRES: 15,   // a kick-in must gain at least this much ground
  MAX_RANGE_METRES: 65,
  PLAY_ON_CHANCE: 0.1,      // the kicker runs the ball out of the square instead
  PLAY_ON_METRES: 12,
});

/** Where the defending side takes a kick-in, given the direction the SHOOTING side attacked. */
export const kickInSpot = (shooterAttackedLeft) => [shooterAttackedLeft ? 8 : 92, 50];

// ---- 7. OUT ON THE FULL -----------------------------------------------------
// Share of failed kicks that cross the boundary line untouched (free kick to the
// opposition). The rest are knocked out by a player and become a boundary throw-in.
export const OUT_ON_THE_FULL_SHARE = 0.5;
// A shot that misses everything goes out wide of the behind post.
export const MISS_EXIT_OFFSET_Y = 12;

// ---- 8. NO SIDEWAYS CHAINS ----------------------------------------------------
export const FLAT_DISPOSAL_METRES = 5;     // gaining less than this (forward) is a "flat" disposal
export const MAX_FLAT_CHAIN = 2;           // consecutive flat disposals allowed
export const BREAKOUT_FORWARD_METRES = 12; // what the disposal after a flat chain must gain
export const FLAT_CHAIN_ZONES = Object.freeze(new Set(["D50", "DM"]));
export const isFlatDisposal = (forwardGained) => forwardGained < FLAT_DISPOSAL_METRES;

// Rule 8 applies from the middle of the ground back. 80 m or more from the goal being attacked is the defensive
// midfield and the defensive 50 (matchRules.zoneOf: DM and D50), without importing zoneOf.
export const FLAT_CHAIN_MIN_GOAL_METRES = 80;
export const inFlatChainZone = (metresToGoal) => metresToGoal > FLAT_CHAIN_MIN_GOAL_METRES;
// A flat disposal that is a kick must stay within handball range: no long kicks across the ground.
export const FLAT_HANDBALL_METRES = 16;