import { resolveActiveSlots as resolveActiveSlotsUncached } from "./matchupEngine.js";
import { getSlotSuitability } from "./positionSuitability.js";
import { getDefaultTimeOnGround } from "./fitnessEngine.js";


// Resolving who plays where is the expensive part of an interchange decision and is asked for the same lineup over and
// over, so the answer is remembered. Callers must treat the returned Map as read-only.
const slotCache = new Map();
const resolveActiveSlots = (entries, substitutions = []) => {
  const key = entries.map((entry) => `${entry.player.id}:${entry.position}:${entry.onField ? 1 : 0}`).join("|")
    + (substitutions.length ? `#${substitutions.map((sub) => `${sub.outgoingId}>${sub.incomingId}@${sub.slot}`).join(",")}` : "");
  let result = slotCache.get(key);
  if (!result) {
    result = resolveActiveSlotsUncached(entries, substitutions);
    if (slotCache.size > 256) slotCache.clear();
    slotCache.set(key, result);
  }
  return result;
};

export const rotationStatus = (entry, rotations) =>
  (rotations?.[String(entry.player.id)] ?? (String(entry.position).startsWith("INT") ? "BENCH" : "ON")) === "ON";

/** The entries on the ground now: [{ ...entry, position: slot }], after rotations and the manager's substitutions. */
export function onFieldEntries(entries = [], rotations = {}, substitutions = []) {
  const live = entries.map((entry) => ({ ...entry, onField: rotationStatus(entry, rotations) }));
  return [...resolveActiveSlots(live, substitutions)].map(([position, entry]) => ({ ...entry, position, onField: true }));
}

/** How many interchange swaps this event allows: only at natural breaks, never in the kick itself. */
export function interchangeAllowance(event, { quarterEnded = false, finished = false } = {}) {
  if (finished || event?.type === "SHOT") return 0;
  if (quarterEnded) return 5;
  if (event?.type === "MARK") return 4;
  if (["CENTRE_BOUNCE", "BALL_UP", "THROW_IN"].includes(event?.type)) return 3;
  const benchSide = ["KICK", "HANDBALL", "CARRY", "KICK_IN"].includes(event?.type) && Number(event?.to?.[1]) >= 65;
  return benchSide ? 1 : 0;
}

// Interchange rules for the live match: players only rotate at natural breaks.
// `maxChanges` is the number of swaps allowed in this window and `protectedIds`
// are players who must stay on (the ball carrier, a set-shot taker, their opponent).
export function selectRotationsForMinutes(lineup, rows, previousRotations, elapsedMinutes, plannedTimeOnGround = {}, substitutions = [], { maxChanges = 5, protectedIds = new Set(), unavailableIds = new Set() } = {}) {
  if (!lineup.length) return {};
  const statsById = new Map(rows.map((row) => [String(row.playerId), row]));
  const scoreById = new Map(lineup.map((entry) => {
    const id = String(entry.player.id);
    const plannedPercent = Number(plannedTimeOnGround[id] ?? getDefaultTimeOnGround(entry.player));
    const targetMinutes = Math.max(0, Math.min(100, plannedPercent)) * 0.8;
    const played = Number(statsById.get(id)?.minutesPlayed ?? 0);
    const paceDeficit = targetMinutes * elapsedMinutes / 80 - played;
    const incumbentBonus = (previousRotations?.[id] ?? (entry.position.startsWith("INT") ? "BENCH" : "ON")) === "ON" ? 0.5 : 0;
    return [id, paceDeficit + incumbentBonus];
  }));
  const rotations = Object.fromEntries(lineup.map(({ player, position }) => {
    const id = String(player.id);
    return [id, previousRotations?.[id] ?? (position.startsWith("INT") ? "BENCH" : "ON")];
  }));
  const withCurrentStatus = () => lineup.map((entry) => ({
    ...entry,
    onField: rotations[String(entry.player.id)] === "ON",
  }));

  // Recover old saves with fewer than 18 active statuses. The assignment
  // chooses the strongest available cover and moves others as necessary.
  const currentIds = new Set([...resolveActiveSlots(withCurrentStatus(), substitutions).values()]
    .map((entry) => String(entry.player.id)));
  for (const id of Object.keys(rotations)) rotations[id] = currentIds.has(id) ? "ON" : "BENCH";

  // Trade minutes for role fit when rotating. The full assignment can shift
  // other players into their secondary roles to cover the incoming player.
  for (let change = 0; change < maxChanges; change += 1) {
    const activeSlots = resolveActiveSlots(withCurrentStatus(), substitutions);
    const activeIds = new Set([...activeSlots.values()].map((entry) => String(entry.player.id)));
    let bestMove = null;
    for (const [slot, currentEntry] of activeSlots) {
      const currentId = String(currentEntry.player.id);
      if (protectedIds.has(currentId)) continue;
      for (const candidate of lineup) {
        const candidateId = String(candidate.player.id);
        if (activeIds.has(candidateId) || unavailableIds.has(candidateId)) continue;
        const currentFit = getSlotSuitability(currentEntry.player, slot).overall;
        const candidateFit = getSlotSuitability(candidate.player, slot).overall;
        // If the reserve is a poor positional fit, keep the incumbent on the
        // ground until a more suitable rotation is available.
        if (candidateFit < Math.max(50, currentFit - 8)) continue;
        const ratingChange = candidateFit - currentFit;
        const improvement = (scoreById.get(candidateId) ?? 0) - (scoreById.get(currentId) ?? 0)
          + ratingChange * 0.12;
        if (improvement > 2 && (!bestMove || improvement > bestMove.improvement)) {
          bestMove = { slot, currentId, candidateId, improvement };
        }
      }
    }
    if (!bestMove) break;
    rotations[bestMove.currentId] = "BENCH";
    rotations[bestMove.candidateId] = "ON";
  }
  const assignedIds = new Set([...resolveActiveSlots(withCurrentStatus(), substitutions).values()]
    .map((entry) => String(entry.player.id)));
  return Object.fromEntries(Object.keys(rotations).map((id) => [id, assignedIds.has(id) ? "ON" : "BENCH"]));
}