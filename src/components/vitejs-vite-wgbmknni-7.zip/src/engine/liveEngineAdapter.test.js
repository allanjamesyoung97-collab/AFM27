import test from "node:test";
import assert from "node:assert/strict";
import { players } from "../data/players.js";
import { createAssistantTeamSelection } from "./teamSelectionEngine.js";
import { advanceWithEngine, createEngineHandle } from "./liveEngineAdapter.js";
import { auditPlayedMatch } from "./matchEventAudit.js";
import { LIVE_MATCH_STAT_KEYS } from "./liveMatchActionStats.js";
import { DEFAULT_TACTICS } from "./tacticsEngine.js";

const lineupFor = (club) => {
  const squad = players.filter((player) => player.club === club);
  const selected = createAssistantTeamSelection(squad).selectedSide;
  return Object.entries(selected).filter(([, name]) => name).map(([position, name]) => ({ position, player: squad.find((player) => player.name === name) }));
};
const statRows = (lineup) => lineup.map(({ player, position }) => ({
  player, onField: !position.startsWith("INT"), playerId: player.id, playerName: player.name, club: player.club,
  timeOnGround: 0, minutesPlayed: 0, ...Object.fromEntries(LIVE_MATCH_STAT_KEYS.map((key) => [key, 0])),
}));
const helpers = {
  quarterSeconds: 1200, quarterLabels: ["First quarter", "Second quarter", "Third quarter", "Fourth quarter"],
  formatQuarterClock: (seconds) => `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(Math.floor(seconds % 60)).padStart(2, "0")}`,
  summarizeTeamStats: (rows) => ({ disposals: rows.reduce((sum, row) => sum + row.disposals, 0) }),
};

function startMatch(seed = 5) {
  const homeLineup = lineupFor("Essendon");
  const awayLineup = lineupFor("Collingwood");
  const match = {
    homeTeam: "Essendon", awayTeam: "Collingwood", homeScore: 0, awayScore: 0, homeGoals: 0, homeBehinds: 0, awayGoals: 0, awayBehinds: 0,
    quarter: 1, minute: 0, elapsedSeconds: 0, secondsRemaining: 1200, possession: 50, momentum: 0, intensity: 58, tactics: DEFAULT_TACTICS,
    managerSide: "home", events: [], actions: [], scoreEvents: [], status: "LIVE", engineMode: true, engineSeed: seed,
    homeStrength: 0, awayStrength: 0, playerStats: { home: statRows(homeLineup), away: statRows(awayLineup) },
  };
  return { match, options: { handle: createEngineHandle(), homeLineup, awayLineup, helpers } };
}

// Plays the match the way Match Centre does: tick while LIVE, continue after each quarter break.
function playOut(seed) {
  const { match: first, options } = startMatch(seed);
  let match = first;
  const ticks = [];
  for (let guard = 0; guard < 20000 && match.status !== "FULL_TIME"; guard += 1) {
    if (match.status === "QUARTER_BREAK") { match = { ...match, status: "LIVE", quarter: match.quarter + 1, secondsRemaining: 1200, ballSequence: null, spatialQuarter: null }; continue; }
    const before = match;
    match = advanceWithEngine(match, options);
    ticks.push({ before, after: match });
  }
  return { match, ticks };
}

test("a match played through the adapter reaches full time in four quarters with a clean audit", () => {
  const { match } = playOut(5);
  assert.equal(match.status, "FULL_TIME");
  assert.equal(match.quarter, 4);
  const audit = auditPlayedMatch(match);
  assert.deepEqual(audit.problems, []);
  assert.ok(audit.eventCount > 1000);
  assert.equal(match.homeScore, match.homeGoals * 6 + match.homeBehinds);
  assert.equal(match.awayScore, match.awayGoals * 6 + match.awayBehinds);
  assert.equal(match.scoreEvents.length, match.homeGoals + match.homeBehinds + match.awayGoals + match.awayBehinds);
});

test("every tick changes the animation id, and the last action matches it", () => {
  const { ticks } = playOut(6);
  let previousId;
  for (const { after } of ticks) {
    if (after.status === "QUARTER_BREAK" && after.visualAction?.id === previousId) continue;
    assert.notEqual(after.visualAction?.id, previousId, "visualAction id repeated");
    previousId = after.visualAction.id;
    if (after.visualAction.kind !== "setup") assert.equal(after.actions.at(-1).id, after.visualAction.id);
  }
});

test("box-score stats track the event log and goal scorers are credited", () => {
  const { match } = playOut(7);
  for (const side of ["home", "away"]) {
    assert.equal(match.playerStats[side].reduce((sum, row) => sum + row.goals, 0), match[`${side}Goals`]);
    assert.ok(match.playerStats[side].reduce((sum, row) => sum + row.hitouts, 0) > 5, "hitouts recorded");
    assert.ok(match.playerStats[side].some((row) => row.timeOnGround >= 60 && row.minutesPlayed >= 50), "time on ground accumulates as a share of the match");
  }
  assert.ok(match.teamStats.home.disposals > 150);
});

test("setup actions carry a formation, and play positions are present", () => {
  const { ticks } = playOut(8);
  const setups = ticks.filter(({ after }) => after.visualAction?.kind === "setup");
  assert.ok(setups.length > 20);
  for (const { after } of setups.slice(0, 5)) {
    assert.ok(after.visualAction.duration >= 1500);
    assert.equal(Object.keys(after.spatialPositions).length, 36);
    assert.equal(after.spatialQuarter, after.quarter);
  }
  const mid = ticks[Math.floor(ticks.length / 2)].after;
  assert.equal(Object.keys(mid.spatialPositions).length, 36);
});

test("the same seed replays identically and the match can be resumed from JSON", () => {
  const a = playOut(9).match;
  const b = playOut(9).match;
  assert.equal(JSON.stringify(a.eventLog), JSON.stringify(b.eventLog));
  // Stop part-way, serialise, and carry on with a fresh handle.
  const { match: start, options } = startMatch(9);
  let match = start;
  for (let i = 0; i < 400; i += 1) match = advanceWithEngine(match, options);
  const resumed = JSON.parse(JSON.stringify({ ...match, playerStats: undefined }));
  resumed.playerStats = match.playerStats;
  const fresh = { ...options, handle: createEngineHandle() };
  let x = match; let y = resumed;
  for (let i = 0; i < 200; i += 1) { x = advanceWithEngine(x, options); y = advanceWithEngine(y, fresh); }
  assert.equal(JSON.stringify(x.eventLog), JSON.stringify(y.eventLog));
});

test("it does nothing unless the match is live", () => {
  const { match, options } = startMatch();
  assert.equal(advanceWithEngine({ ...match, status: "PAUSED" }, options).status, "PAUSED");
});
// ---- rotations, substitutions, instructions ----------------------------------------------------------------------
const onFieldCount = (match, side) => match.playerStats[side].filter((row) => row.onField).length;

test("interchange: the bench is used at natural breaks and eighteen are always on the ground", () => {
  const { match: first, options } = startMatch(11);
  let match = first;
  for (let guard = 0; guard < 20000 && match.status !== "FULL_TIME"; guard += 1) {
    if (match.status === "QUARTER_BREAK") { match = { ...match, status: "LIVE", quarter: match.quarter + 1, secondsRemaining: 1200, ballSequence: null, spatialQuarter: null }; continue; }
    match = advanceWithEngine(match, options);
    for (const side of ["home", "away"]) assert.equal(onFieldCount(match, side), 18, `${side} must always have 18 on the ground`);
  }
  for (const side of ["home", "away"]) {
    const bench = match.playerStats[side].filter((row) => row.fieldSlot === undefined || row.minutesPlayed > 0);
    const benchWhoPlayed = match.playerStats[side].filter((row, index) => index >= 18 && row.minutesPlayed > 1);
    assert.ok(benchWhoPlayed.length >= 2, `${side}: at least two interchange players should get a run (got ${benchWhoPlayed.length})`);
    assert.ok(bench.length >= 18);
    assert.ok(Object.keys(match.rotations ?? {}).length >= 22, "rotations are tracked for the whole squad");
  }
  assert.deepEqual(auditPlayedMatch(match).problems, []);
});

test("substitution: a player taken off stops being involved and his replacement takes his place", () => {
  const { match: first, options } = startMatch(12);
  let match = first;
  let swapped = null;
  const before = {};
  const afterTenMinutes = {};
  for (let guard = 0; guard < 20000 && match.status !== "FULL_TIME"; guard += 1) {
    if (match.status === "QUARTER_BREAK") { match = { ...match, status: "LIVE", quarter: match.quarter + 1, secondsRemaining: 1200, ballSequence: null, spatialQuarter: null }; continue; }
    if (!swapped && match.elapsedSeconds > 900 && options.homeLineup.length > 18) {
      const outgoing = options.homeLineup.find((entry) => !entry.position.startsWith("INT") && match.rotations?.[String(entry.player.id)] !== "BENCH" && entry.position === "C");
      const incoming = options.homeLineup.find((entry) => entry.position.startsWith("INT") && match.rotations?.[String(entry.player.id)] !== "ON");
      if (outgoing && incoming) {
        swapped = { out: String(outgoing.player.id), in: String(incoming.player.id), at: match.elapsedSeconds };
        const statsOf = (id) => match.playerStats.home.find((row) => String(row.playerId) === id);
        before.out = statsOf(swapped.out).disposals; before.in = statsOf(swapped.in).disposals;
        match = { ...match, rotations: { ...match.rotations, [swapped.out]: "BENCH", [swapped.in]: "ON" },
          substitutions: [...(match.substitutions ?? []), { minute: Math.floor(match.elapsedSeconds / 60), slot: "C", outgoingId: outgoing.player.id, incomingId: incoming.player.id }] };
      }
    }
    match = advanceWithEngine(match, options);
    if (swapped && !swapped.checkedAt && match.elapsedSeconds >= swapped.at + 600) {
      swapped.checkedAt = match.elapsedSeconds;
      afterTenMinutes.out = match.playerStats.home.find((row) => String(row.playerId) === swapped.out).disposals;
    }
  }
  assert.ok(swapped, "a substitution was made");
  const after = (id) => match.playerStats.home.find((row) => String(row.playerId) === id);
  assert.equal(afterTenMinutes.out, before.out, "the player who went off adds nothing for the next ten minutes");
  assert.ok(after(swapped.in).disposals > before.in, "the player who came on is involved");
  assert.ok(after(swapped.in).minutesPlayed > 5);
});

test("a match started before the engine became the only one carries on from its quarter and score", () => {
  const { match: first, options } = startMatch(13);
  const legacy = { ...first, engineMode: undefined, engine: undefined, quarter: 2, elapsedSeconds: 1500, secondsRemaining: 900, homeScore: 30, homeGoals: 4, homeBehinds: 6, awayScore: 20, awayGoals: 3, awayBehinds: 2 };
  const next = advanceWithEngine(legacy, options);
  assert.equal(next.quarter, 2);
  assert.ok(next.homeScore >= 30 && next.awayScore >= 20, "the score is carried over");
});