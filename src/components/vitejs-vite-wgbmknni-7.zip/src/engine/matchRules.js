// The match rulebook. Pure data and pure functions, no React, no randomness.
//
// These are the rules the seeded match engine (matchSimEngine.js), the
// experimental adapter (liveEngineAdapter.js) and the presentation pacing
// (liveMatchPacing.js) must all obey. The engine uses them to CONSTRAIN what it
// decides; auditMatchRules() uses the same definitions to CHECK a finished event
// log, so a rule can't quietly be true in one place and false in another.
//
// The rules, in plain English:
//
//   1. BALL      The ball is one continuous object. It always sits inside the
//                boundary line, and it only leaves play by travelling there.
//                Nothing drags it somewhere its flight did not carry it.
//   2. DIRECTION A side with the ball moves it toward its own goal. A disposal
//                may go sideways, and may go backwards only as far as the zone
//                allows (and never backwards inside the forward 50).
//   3. GOAL      A player in on goal does not retreat. With no legal forward
//                option he has a shot, or he runs on.
//   4. FLOW      Play keeps moving. Only a centre bounce, a goal, a set shot
//                and the quarter breaks may hold play while the oval catches
//                up. A ball-up or boundary throw-in never waits for players
//                to arrange themselves.
//   5. SOURCE    The event log is the single source of truth. The adapter and
//                the oval read positions from the engine; they never invent
//                their own.
import { METRES_PER_X, METRES_PER_Y, distanceToGoal } from "./matchPresentation.js";
import { attacksLeft } from "./matchEvents.js";
import {
  KICK_IN, OUT_ON_THE_FULL_SHARE, MISS_EXIT_OFFSET_Y, FLAT_DISPOSAL_METRES, MAX_FLAT_CHAIN, BREAKOUT_FORWARD_METRES,
  FLAT_CHAIN_ZONES, isFlatDisposal, kickInSpot,
} from "./restartRules.js";

// Rules 6-8 (kick-in, out on the full, no sideways chains) live in restartRules.js so presentation code can use
// them without importing this file.
export {
  KICK_IN, OUT_ON_THE_FULL_SHARE, MISS_EXIT_OFFSET_Y, FLAT_DISPOSAL_METRES, MAX_FLAT_CHAIN, BREAKOUT_FORWARD_METRES,
  FLAT_CHAIN_ZONES, isFlatDisposal, kickInSpot,
};

// ---- 1. BALL: the ground ----------------------------------------------------
// BOUNDARY is the painted line the ball must stay inside (the visible oval in
// LiveMatchOval). PLAYER_OVAL is where players are allowed to stand, a little
// inside it (planOvalMovement clamps to this).
export const BOUNDARY = Object.freeze({ cx: 50, cy: 50, rx: 45.5, ry: 44 });
export const PLAYER_OVAL = Object.freeze({ cx: 50, cy: 50, rx: 44, ry: 42 });

export const metresBetween = (a, b) => Math.hypot((a[0] - b[0]) * METRES_PER_X, (a[1] - b[1]) * METRES_PER_Y);

/** 1 on the oval's edge, below 1 inside it, above 1 outside it. */
export const ovalRatio = (point, oval = BOUNDARY) => Math.hypot((point[0] - oval.cx) / oval.rx, (point[1] - oval.cy) / oval.ry);
export const insideBoundary = (point, tolerance = 0.002) => ovalRatio(point) <= 1 + tolerance;

/** Metres from a point to the boundary, measured outward from the centre of the ground. */
export function metresToBoundary(point, oval = BOUNDARY) {
  return ovalRatio(point, oval) >= 1 ? 0 : metresBetween(point, boundaryProjection(point, oval));
}

/** The boundary point straight out from the centre of the ground through `point`. */
export function boundaryProjection(point, oval = BOUNDARY) {
  const ratio = ovalRatio(point, oval);
  if (ratio < 1e-6) return [oval.cx + oval.rx, oval.cy];
  return [oval.cx + (point[0] - oval.cx) / ratio, oval.cy + (point[1] - oval.cy) / ratio];
}

/**
 * Out of bounds only happens to a kick that misses its target and drifts over
 * the line. The ball is put on the line where it crossed, after a flight that
 * the event records, so it is never moved without travelling. A kick aimed
 * more than OUT_OF_BOUNDS_REACH_METRES from the line cannot go out, and nor can
 * one that would have to fly further than a kick can.
 */
export const OUT_OF_BOUNDS_REACH_METRES = 45;
export const MAX_KICK_METRES = 80;
export function outOfBoundsChance(baseChance, origin, target, reach = OUT_OF_BOUNDS_REACH_METRES) {
  const exit = boundaryProjection(target);
  if (metresBetween(origin, exit) > MAX_KICK_METRES) return 0;
  return baseChance * Math.max(0, 1 - metresBetween(target, exit) / reach);
}

/**
 * Where a shot that misses everything leaves the ground: out on the full, wide of the behind post on the side
 * given by `sign` (1 or -1). Always a point on the boundary, so the free kick that follows is taken from the line.
 */
export function missExitPoint(shooterAttackedLeft, sign = 1) {
  return boundaryProjection([shooterAttackedLeft ? 5 : 95, 50 + (sign < 0 ? -1 : 1) * MISS_EXIT_OFFSET_Y]);
}

// ---- 2. DIRECTION -----------------------------------------------------------
export const zoneOf = (metresToGoal) => (metresToGoal <= 50 ? "F50" : metresToGoal <= 80 ? "FM" : metresToGoal <= 110 ? "DM" : "D50");

/** Metres gained toward the goal this side attacks (negative is backwards). */
export const forwardMetres = (from, to, attackingLeft) => (attackingLeft ? from[0] - to[0] : to[0] - from[0]) * METRES_PER_X;

/**
 * The furthest a disposal may go backwards, by what it is and where the carrier
 * is. Inside the forward 50 a pass may go square or a few metres back to a
 * teammate in space, but a kick never retreats out of the forward half and a
 * defender is the only one who may rebound it a long way.
 */
export const MAX_BACKWARD_METRES = Object.freeze({
  KICK: Object.freeze({ F50: 8, FM: 10, DM: 10, D50: 12 }),
  HANDBALL: Object.freeze({ F50: 10, FM: 10, DM: 10, D50: 10 }),
});
export const maxBackwardMetres = (kind, zone) => (MAX_BACKWARD_METRES[kind] ?? MAX_BACKWARD_METRES.KICK)[zone] ?? 0;

// ---- 3. GOAL ----------------------------------------------------------------
// A player in on goal does not retreat. When no teammate is a legal forward
// option he takes the shot, out to FORCED_SHOT_METRES, and beyond that he runs
// on toward goal. (How OFTEN a player chooses to shoot is a tuning matter and
// stays in matchSimEngine's DEFAULT_TUNING; this rule only removes the retreat.)
export const FORCED_SHOT_METRES = 55;

// ---- 4. FLOW ----------------------------------------------------------------
// Only these restarts hold play while the oval arranges the teams.
export const GATED_RESTARTS = Object.freeze(new Set(["CENTRE_BOUNCE"]));
export const isGatedRestart = (type) => GATED_RESTARTS.has(type);
// How long, in game seconds, players are given to reach a stoppage. Presentation
// does not wait for this: they run to the contest while play continues.
export const STOPPAGE_MOVEMENT_SECONDS = Object.freeze({ BALL_UP: 4.5, THROW_IN: 4.5 });
// The longest the oval may hold a non-gated action, in ms at 1x speed. A flying
// ball is not a hold, so this applies to actions where the ball is stationary.
export const MAX_STATIONARY_HOLD_MS = 2000;

// ---- the audit --------------------------------------------------------------
const DISPOSALS = new Set(["KICK", "HANDBALL", "KICK_IN"]);
const BALL_CONTINUES = new Set(["GOAL", "BEHIND", "MISS", "SHORT", "OUT_OF_BOUNDS", "STOPPAGE", "RUSHED_BEHIND"]);
const RESTARTS = new Set(["CENTRE_BOUNCE", "KICK_IN", "THROW_IN", "BALL_UP"]);
const BALL_JUMP_METRES = 12;

/**
 * Check a finished event log against the rules. Returns
 * { ok, counts, violations } where each violation is { rule, seq, message }.
 */
export function auditMatchRules(events, { maxViolations = 40 } = {}) {
  const violations = [];
  const counts = {};
  const flag = (rule, event, message) => {
    counts[rule] = (counts[rule] ?? 0) + 1;
    if (violations.length < maxViolations) violations.push({ rule, seq: event.seq, message });
  };

  let previous = null;
  let flatRun = 0;
  let flatSide = null;
  for (const event of events) {
    const flow = event.type === "QUARTER_START" || event.type === "QUARTER_END" || event.type === "FULL_TIME";
    if (flow) { previous = null; continue; }
    const left = attacksLeft(event.side, event.quarter);

    // 1. BALL
    for (const key of ["from", "to"]) {
      if (event[key] && !insideBoundary(event[key])) flag("BALL_OUTSIDE_BOUNDARY", event, `${event.type} ${key} ${event[key].map((n) => n.toFixed(1))} is outside the boundary`);
    }
    if (event.outcome === "OUT_OF_BOUNDS") {
      if (!event.to || Math.abs(ovalRatio(event.to) - 1) > 0.01) flag("OUT_OF_BOUNDS_OFF_THE_LINE", event, "an out-of-bounds ball must finish on the boundary line");
      const flown = event.from && event.to ? metresBetween(event.from, event.to) : 0;
      if (Math.abs((event.distance ?? 0) - flown) > 3) flag("BALL_DRAGGED", event, `out of bounds after ${flown.toFixed(0)}m but the event records ${event.distance ?? 0}m of flight`);
      if (flown > MAX_KICK_METRES) flag("BALL_DRAGGED", event, `out-of-bounds kick covers ${flown.toFixed(0)}m`);
    }
    if (previous && event.from && !RESTARTS.has(event.type) && !BALL_CONTINUES.has(previous.outcome) && previous.type !== "SHOT") {
      const last = previous.to ?? previous.from;
      if (last && metresBetween(last, event.from) > BALL_JUMP_METRES) {
        flag("BALL_JUMP", event, `ball jumps ${metresBetween(last, event.from).toFixed(0)}m between ${previous.type} and ${event.type}`);
      }
    }

    // 2. DIRECTION
    if (DISPOSALS.has(event.type) && event.from && event.to && event.outcome !== "OUT_OF_BOUNDS") {
      const kind = event.type === "HANDBALL" ? "HANDBALL" : "KICK";
      const zone = zoneOf(distanceToGoal(event.from, left));
      const gained = forwardMetres(event.from, event.to, left);
      if (gained < -maxBackwardMetres(kind, zone) - 1) {
        flag(zone === "F50" ? "RETREAT_IN_ATTACK" : "BACKWARD_DISPOSAL", event,
          `${kind.toLowerCase()} from ${zone} (${Math.round(distanceToGoal(event.from, left))}m out) goes ${Math.round(-gained)}m backwards`);
      }
    }

    // 6. KICK-IN: an unpressured kick from the square that must gain real ground.
    if (event.type === "KICK_IN" && event.receiverId != null && event.outcome !== "OUT_OF_BOUNDS" && event.from && event.to) {
      const gained = forwardMetres(event.from, event.to, left);
      if (gained < KICK_IN.MIN_FORWARD_METRES - 1) {
        flag("KICK_IN_SIDEWAYS", event, `kick-in gains only ${Math.round(gained)}m (minimum ${KICK_IN.MIN_FORWARD_METRES}m)`);
      }
    }

    // 8. NO SIDEWAYS CHAINS: consecutive flat, successful disposals by one side outside the forward half.
    const isDisposal = DISPOSALS.has(event.type) && event.outcome === "RETAINED" && event.from && event.to;
    if (isDisposal) {
      const zone = zoneOf(distanceToGoal(event.from, left));
      const flat = FLAT_CHAIN_ZONES.has(zone) && isFlatDisposal(forwardMetres(event.from, event.to, left));
      if (flat) {
        flatRun = flatSide === event.side ? flatRun + 1 : 1;
        flatSide = event.side;
        if (flatRun > MAX_FLAT_CHAIN) flag("SIDEWAYS_CHAIN", event, `${flatRun} flat disposals in a row from ${zone}`);
      } else { flatRun = 0; flatSide = null; }
    } else if (event.type !== "MARK") { flatRun = 0; flatSide = null; }
    previous = event;
  }
  return { ok: violations.length === 0, counts, violations };
}