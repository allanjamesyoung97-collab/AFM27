import {
  clubs,
  clubVenues
} from "../data/clubData.js";
import { leagueClubsForYear } from "../data/clubs.js";
import { AFL_2027_FIXTURE } from "../data/fixture2027.js";

const DOUBLE_UP_ROUNDS = [
  // Round 18 - Traditional Rivalries

  [
    ["Collingwood", "Carlton"],
    ["Adelaide", "Port Adelaide"],
    ["West Coast", "Fremantle"],
    ["Sydney", "GWS"],
    ["Richmond", "Essendon"],
    ["Melbourne", "Western Bulldogs"],
    ["Geelong", "Hawthorn"],
    ["St Kilda", "North Melbourne"],
    ["Brisbane", "Gold Coast"]
  ],

  // Round 19 - Top Clubs

  [
    ["Collingwood", "Brisbane"],
    ["Fremantle", "Sydney"],
    ["Geelong", "Western Bulldogs"],
    ["Hawthorn", "Carlton"],
    ["Melbourne", "Adelaide"],
    ["GWS", "Port Adelaide"],
    ["Gold Coast", "St Kilda"],
    ["Essendon", "North Melbourne"],
    ["Richmond", "West Coast"]
  ],

  // Round 20 - Interstate Matchups

  [
    ["Adelaide", "West Coast"],
    ["Port Adelaide", "Fremantle"],
    ["Brisbane", "Sydney"],
    ["Gold Coast", "GWS"],
    ["Collingwood", "Richmond"],
    ["Carlton", "Essendon"],
    ["Melbourne", "Geelong"],
    ["Hawthorn", "Western Bulldogs"],
    ["St Kilda", "North Melbourne"]
  ],

  // Round 21 - Historic Rivalries

  [
    ["Collingwood", "Essendon"],
    ["Carlton", "Richmond"],
    ["Melbourne", "Hawthorn"],
    ["Geelong", "Western Bulldogs"],
    ["Sydney", "West Coast"],
    ["Fremantle", "Adelaide"],
    ["Port Adelaide", "Brisbane"],
    ["Gold Coast", "GWS"],
    ["North Melbourne", "St Kilda"]
  ],

  // Round 22 - Finals Race

  [
    ["Collingwood", "Sydney"],
    ["Brisbane", "Geelong"],
    ["Fremantle", "Hawthorn"],
    ["Carlton", "Western Bulldogs"],
    ["Melbourne", "GWS"],
    ["Adelaide", "Gold Coast"],
    ["Port Adelaide", "St Kilda"],
    ["Essendon", "Richmond"],
    ["North Melbourne", "West Coast"]
  ],

  // Round 23 - Season Finale

  [
    ["Collingwood", "Geelong"],
    ["Brisbane", "Fremantle"],
    ["Sydney", "Western Bulldogs"],
    ["Hawthorn", "Melbourne"],
    ["Carlton", "Port Adelaide"],
    ["Adelaide", "GWS"],
    ["Gold Coast", "West Coast"],
    ["Essendon", "St Kilda"],
    ["Richmond", "North Melbourne"]
  ]
];

export function generateFixture(seasonYear = 2027) {
  const teams = leagueClubsForYear(seasonYear).map((club) => club.name);
  if (Number(seasonYear) === 2027) {
    return AFL_2027_FIXTURE.map((round) => ({
      ...round,
      floating: round.round >= 17,
      bye: teams.filter((club) => !round.matches.some((match) => match.home === club || match.away === club)),
      matches: round.matches.map((match) => ({ ...match })),
    }));
  }
  if (Number(seasonYear) >= 2028) {
    return generateRandomizedExpansionFixture(seasonYear, teams);
  }

  const rounds = generateRoundRobin(seasonYear, teams);
  const doubleUpRounds = teams.length === 18
    ? generateDoubleUpRounds(seasonYear)
    : generateExpansionDoubleUpRounds(seasonYear, teams);

  return [
    ...rounds,
    ...doubleUpRounds
  ];
}

function generateRandomizedExpansionFixture(seasonYear, teamNames) {
  const bye = null;
  const participants = shuffle([...teamNames, bye]);
  const rotation = [...participants];
  const rounds = [];
  const playedPairs = new Map();

  // A 19-team round robin gives every club one bye and one meeting with each
  // of the other 18 clubs. Five extra rounds add a second bye for five clubs.
  for (let round = 1; round <= 19; round += 1) {
    rounds.push(makeRandomizedRound(round, rotation, seasonYear, playedPairs));
    rotateTeams(rotation);
  }

  const secondByeClubs = shuffle([...teamNames]).slice(0, 5);
  const extraByes = shuffle(secondByeClubs);
  for (let index = 0; index < 5; index += 1) {
    const roundNumber = 20 + index;
    rounds.push(makeRandomizedExtraRound(
      roundNumber,
      teamNames,
      extraByes[index],
      seasonYear,
      playedPairs,
    ));
  }

  return rounds;
}

function makeRandomizedRound(round, rotation, seasonYear, playedPairs) {
  const matches = [];
  let byeClub = null;
  for (let index = 0; index < rotation.length / 2; index += 1) {
    const first = rotation[index];
    const second = rotation[rotation.length - 1 - index];
    if (!first || !second) {
      byeClub = first ?? second;
      continue;
    }
    const [home, away] = Math.random() < 0.5 ? [first, second] : [second, first];
    matches.push(randomizedMatch(home, away, seasonYear, round));
    recordPair(playedPairs, home, away);
  }
  return { round, matches, bye: byeClub ? [byeClub] : [] };
}

function makeRandomizedExtraRound(round, teams, byeClub, seasonYear, playedPairs) {
  const playingTeams = teams.filter((club) => club !== byeClub);
  let pairings;
  for (let attempt = 0; attempt < 250; attempt += 1) {
    const shuffled = shuffle(playingTeams);
    const candidate = Array.from({ length: shuffled.length / 2 }, (_, index) => [
      shuffled[index * 2],
      shuffled[index * 2 + 1],
    ]);
    if (candidate.every(([a, b]) => (playedPairs.get(pairKey(a, b)) ?? 0) < 2)) {
      pairings = candidate;
      break;
    }
  }
  pairings ??= Array.from({ length: playingTeams.length / 2 }, (_, index) => [
    playingTeams[index * 2],
    playingTeams[index * 2 + 1],
  ]);

  const matches = pairings.map(([first, second]) => {
    const [home, away] = Math.random() < 0.5 ? [first, second] : [second, first];
    recordPair(playedPairs, home, away);
    return randomizedMatch(home, away, seasonYear, round);
  });
  return { round, matches, bye: [byeClub] };
}

function randomizedMatch(home, away, seasonYear, round) {
  return {
    home,
    away,
    venue: venueForClub(home, seasonYear, round),
    date: getRoundDate(round, seasonYear),
  };
}

function recordPair(playedPairs, first, second) {
  const key = pairKey(first, second);
  playedPairs.set(key, (playedPairs.get(key) ?? 0) + 1);
}

function pairKey(first, second) {
  return [first, second].sort().join("::");
}

function shuffle(values) {
  const shuffled = [...values];
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const swapIndex = Math.floor(Math.random() * (index + 1));
    [shuffled[index], shuffled[swapIndex]] = [shuffled[swapIndex], shuffled[index]];
  }
  return shuffled;
}

function generateRoundRobin(seasonYear, teamNames = clubs.map((club) => club.name)) {
  const teams = [...teamNames];
  if (teams.length % 2) teams.push(null);
  const seasonOffset = ((seasonYear - 2027) % teams.length + teams.length) % teams.length;
  const seasonOrder = [...teams.slice(seasonOffset), ...teams.slice(0, seasonOffset)];

  const rotation =
    [...seasonOrder];

  const rounds = [];

  for (let round = 1; round < rotation.length; round++) {
    const matches = [];

    for (let i = 0; i < rotation.length / 2; i++) {
      let home;
      let away;

      if (round % 2 === 0) {
        home =
          rotation[
            rotation.length -
              1 -
              i
          ];

        away =
          rotation[i];
      } else {
        home =
          rotation[i];

        away =
          rotation[
            rotation.length -
              1 -
              i
          ];
      }

      if (!home || !away) continue;
      matches.push({
        home,
        away,
        venue:
            venueForClub(home, seasonYear, round),
        date:
          getRoundDate(
            round,
            seasonYear
          )
      });
    }

    rounds.push({
      round,
      matches
    });

    rotateTeams(
      rotation
    );
  }

  return rounds;
}

function generateDoubleUpRounds(seasonYear) {
  const teamNames = clubs.map((club) => club.name);
  const yearOffset = ((seasonYear - 2027) % teamNames.length + teamNames.length) % teamNames.length;
  const reverseHomeAway = (seasonYear - 2027) % 2 !== 0;

  return DOUBLE_UP_ROUNDS.map(
    (
      roundFixtures,
      index
    ) => ({
      round: 18 + index,

      matches:
        roundFixtures.map(
          (fixture) => {
            const shiftClub = (clubName) => {
              const teamIndex = teamNames.indexOf(clubName);
              return teamNames[(teamIndex + yearOffset) % teamNames.length];
            };
            const shiftedHome = shiftClub(fixture[0]);
            const shiftedAway = shiftClub(fixture[1]);
            const home = reverseHomeAway ? shiftedAway : shiftedHome;
            const away = reverseHomeAway ? shiftedHome : shiftedAway;

            return {
              home,
              away,
              venue: clubVenues[home],
              date: getRoundDate(18 + index, seasonYear),
            };
          }
        )
    })
  );
}

function generateExpansionDoubleUpRounds(seasonYear, teams) {
  const rounds = generateRoundRobin(seasonYear + 1, teams).slice(0, 5);
  return rounds.map((round, index) => ({
    round: 20 + index,
    matches: round.matches.map((match) => ({
      home: index % 2 ? match.away : match.home,
      away: index % 2 ? match.home : match.away,
      venue: venueForClub(index % 2 ? match.away : match.home, seasonYear, 20 + index),
      date: getRoundDate(20 + index, seasonYear),
    })),
  }));
}

function venueForClub(clubName, year, round) {
  if (clubName !== "Tasmania") return clubVenues[clubName];
  if (Number(year) >= 2031) return "Macquarie Point Stadium";
  return Number(round) % 2 ? "York Park" : "Bellerive Oval";
}

function rotateTeams(
  rotation
) {
  const fixed =
    rotation[0];

  const remaining =
    rotation.slice(1);

  remaining.unshift(
    remaining.pop()
  );

  rotation.splice(
    0,
    rotation.length,
    fixed,
    ...remaining
  );
}

function getRoundDate(
  round,
  seasonYear
) {
  const startDate =
    new Date(
      Date.UTC(seasonYear, 2, 18, 12)
    );

  startDate.setDate(
    startDate.getDate() +
      (round - 1) * 7
  );

  return startDate.toLocaleDateString(
    "en-AU",
    {
      day: "numeric",
      month: "short",
      year: "numeric"
    }
  );
}
