import test from "node:test";
import assert from "node:assert/strict";
import { players } from "../data/players.js";
import { createAssistantTeamSelection } from "./teamSelectionEngine.js";
import { simulateMatchEvents } from "./matchSimEngine.js";
import { auditMatchRules, ovalRatio, metresBetween } from "./matchRules.js";
import { kickInSpot } from "./restartRules.js";

const lineupFor = (club) => {
  const squad = players.filter((player) => player.club === club);
  const selected = createAssistantTeamSelection(squad).selectedSide;
  return Object.entries(selected).filter(([position, name]) => name && !position.startsWith("INT"))
    .map(([position, name]) => ({ position, player: squad.find((player) => player.name === name) }));
};
const play = (seed, home = "Essendon", away = "Collingwood") =>
  simulateMatchEvents({ seed, home: { name: home, lineup: lineupFor(home) }, away: { name: away, lineup: lineupFor(away) } }).events;

// ---- the seeded engine --------------------------------------------------------------------------------------------
test("rule 6: a behind is followed by a kick-in from the goal square, never a stoppage", () => {
  let behinds = 0;
  for (const seed of [3001, 3002, 3003]) {
    const events = play(seed);
    events.forEach((event, i) => {
      if (event.type !== "SHOT" || event.outcome !== "BEHIND") return;
      const next = events[i + 1];
      if (!next || next.type === "QUARTER_END" || next.type === "FULL_TIME") return;
      behinds += 1;
      // The kicker either kicks in or plays on (a run out of the square, a CARRY), from the goal square either way.
      assert.ok(next.type === "KICK_IN" || next.type === "CARRY", `seq ${next.seq}: expected a kick-in or a play-on after a behind, got ${next.type}`);
      assert.notEqual(next.side, event.side, "the defending side kicks in");
      const spot = kickInSpot(next.quarter % 2 === 0 ? event.side === "home" : event.side !== "home");
      assert.ok(metresBetween(next.from, spot) < 1.5, `kick-in is taken from the goal square, not ${next.from}`);
    });
    const stats = events.filter((e) => e.type === "KICK_IN").flatMap((e) => e.statChanges ?? []);
    for (const change of stats) assert.equal(change.stats.hitouts ?? 0, 0, "a kick-in earns no hit-out");
  }
  assert.ok(behinds > 10, "the sample must contain behinds");
});

test("rule 6: every kick-in that reaches a teammate gains real ground", () => {
  for (const seed of [3004, 3005]) {
    const audit = auditMatchRules(play(seed), { maxViolations: 1e9 });
    assert.equal(audit.counts.KICK_IN_SIDEWAYS ?? 0, 0);
  }
});

test("rule 7: a shot that misses everything is a free kick taken on the boundary, not from where it was kicked", () => {
  let misses = 0;
  for (const seed of [3006, 3007, 3008]) {
    const events = play(seed);
    events.forEach((event, i) => {
      if (event.type !== "SHOT" || event.outcome !== "MISS") return;
      const next = events[i + 1];
      if (!next || next.type === "QUARTER_END" || next.type === "FULL_TIME") return;
      misses += 1;
      assert.equal(next.type, "FREE_KICK", `seq ${next.seq}: expected a free kick after a miss, got ${next.type}`);
      assert.ok((next.tags ?? []).includes("OUT_ON_THE_FULL"));
      assert.notEqual(next.side, event.side, "the free kick goes to the other side");
      assert.ok(Math.abs(ovalRatio(next.from) - 1) < 0.02, `the free kick is on the boundary line, not ${next.from}`);
      assert.ok(metresBetween(next.from, event.from) > 5, "the ball does not return to where the shot was taken");
    });
  }
  assert.ok(misses > 10, "the sample must contain misses");
});

test("rule 7: a kick out on the full is a free kick to the opposition where it crossed the line", () => {
  let seen = 0;
  for (const seed of [3009, 3010, 3011]) {
    const events = play(seed);
    events.forEach((event, i) => {
      if (event.outcome !== "OUT_OF_BOUNDS" || !(event.tags ?? []).includes("OUT_ON_THE_FULL")) return;
      const next = events[i + 1];
      if (!next || next.type === "QUARTER_END" || next.type === "FULL_TIME") return;
      seen += 1;
      assert.equal(next.type, "FREE_KICK");
      assert.notEqual(next.side, event.side);
      assert.ok(metresBetween(next.from, event.to) < 1, "the free kick is taken where the ball crossed the line");
    });
  }
  assert.ok(seen > 5);
});

test("rule 8: no long run of sideways disposals from the middle back", () => {
  for (const seed of [3012, 3013, 3014]) {
    const audit = auditMatchRules(play(seed, "Geelong", "Sydney"), { maxViolations: 1e9 });
    assert.equal(audit.counts.SIDEWAYS_CHAIN ?? 0, 0);
  }
});