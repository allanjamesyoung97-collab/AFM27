import test from "node:test";
import assert from "node:assert/strict";
import { players } from "../data/players.js";
import { createAssistantTeamSelection } from "./teamSelectionEngine.js";
import { buildMatchContext, createMatchState, simulateMatchEvents, stepMatch } from "./matchSimEngine.js";
import { verifyEventLog, statsFromEvents, scoreFromEvents } from "./matchEvents.js";
import { LIVE_MATCH_STAT_KEYS } from "./liveMatchActionStats.js";

const lineupFor = (club) => {
 const squad = players.filter((player) => player.club === club);
 const selected = createAssistantTeamSelection(squad).selectedSide;
 return Object.entries(selected).filter(([slot, name]) => name && !slot.startsWith("INT"))
 .map(([position, name]) => ({ position, player: squad.find((player) => player.name === name) }));
};
const config = (seed) => ({ seed, home: { name: "Essendon", lineup: lineupFor("Essendon") }, away: { name: "Collingwood", lineup: lineupFor("Collingwood") } });

test("the same seed replays the same match; a different seed does not", () => {
 const a = simulateMatchEvents(config(11));
 const b = simulateMatchEvents(config(11));
 const c = simulateMatchEvents(config(12));
 assert.equal(JSON.stringify(a.events), JSON.stringify(b.events));
 assert.notEqual(JSON.stringify(a.events), JSON.stringify(c.events));
});

test("the log is sound, the score folds from it, and stats match the box score", () => {
 const result = simulateMatchEvents(config(21));
 assert.deepEqual(verifyEventLog(result.events, { finalScore: result.score }), []);
 assert.deepEqual(scoreFromEvents(result.events), result.score);
 const totals = statsFromEvents(result.events);
 for (const side of ["home", "away"]) {
 let goals = 0;
 for (const row of result.playerStats[side]) {
 goals += row.goals;
 for (const stat of LIVE_MATCH_STAT_KEYS) assert.equal(row[stat], totals.get(`${side}:${row.playerId}`)?.[stat] ?? 0, `${side} ${row.playerName} ${stat}`);
 }
 assert.equal(goals, result.score[side].goals);
 }
});

test("a match is four 20-minute quarters and ends with FULL_TIME", () => {
 const { events, state } = simulateMatchEvents(config(31));
 assert.equal(state.status, "FULL_TIME");
 assert.equal(events.filter((e) => e.type === "QUARTER_START").length, 4);
 assert.equal(events.filter((e) => e.type === "QUARTER_END").length, 3);
 assert.equal(events.at(-1).type, "FULL_TIME");
 assert.equal(events.at(-1).t, 4800);
 for (const quarter of [1, 2, 3, 4]) assert.ok(events.some((e) => e.quarter === quarter && e.type !== "QUARTER_START"));
});

test("stepMatch does not modify its input, and a JSON round trip resumes identically", () => {
 const ctx = buildMatchContext(config(41));
 let state = createMatchState({ seed: 41, ctx });
 for (let i = 0; i < 150; i += 1) state = stepMatch(state, ctx).state;
 const frozen = JSON.stringify(state);
 const resumed = JSON.parse(frozen);
 let live = state;
 const tailA = [];
 const tailB = [];
 for (let i = 0; i < 100; i += 1) { const r = stepMatch(live, ctx); live = r.state; tailA.push(...r.events); }
 assert.equal(JSON.stringify(state), frozen, "input state was mutated");
 let restored = resumed;
 for (let i = 0; i < 100; i += 1) { const r = stepMatch(restored, ctx); restored = r.state; tailB.push(...r.events); }
 assert.equal(JSON.stringify(tailA), JSON.stringify(tailB));
});

test("restarts and shot detail are present in the log", () => {
 const { events } = simulateMatchEvents(config(51));
 assert.ok(events.some((e) => e.type === "CENTRE_BOUNCE"));
 assert.ok(events.some((e) => e.type === "BALL_UP"));
 assert.ok(events.some((e) => e.type === "KICK_IN"));
 const shots = events.filter((e) => e.type === "SHOT");
 assert.ok(shots.length > 20);
 assert.ok(shots.every((e) => Number.isFinite(e.shot.goalDistance) && ["SET", "SNAP", "RUN"].includes(e.shot.kind)));
 assert.ok(shots.filter((e) => e.outcome === "BEHIND" || e.outcome === "MISS").every((e) => ["left", "right"].includes(e.shot.missSide)));
});

test("match shape stays inside broad football bounds (regression guard for tuning)", () => {
 const pairs = [["Essendon", "Collingwood"], ["Geelong", "Sydney"], ["Brisbane", "Carlton"], ["Fremantle", "Hawthorn"]];
 const totals = { points: 0, teams: 0, kicks: 0, handballs: 0, marks: 0, tackles: 0, hitouts: 0, freeKicksFor: 0, clearances: 0, inside50s: 0 };
 pairs.forEach(([home, away], index) => {
 const result = simulateMatchEvents({ seed: 900 + index, home: { name: home, lineup: lineupFor(home) }, away: { name: away, lineup: lineupFor(away) } });
 assert.deepEqual(verifyEventLog(result.events, { finalScore: result.score }), []);
 for (const side of ["home", "away"]) {
 totals.teams += 1;
 totals.points += result.score[side].total;
 for (const row of result.playerStats[side]) for (const key of ["kicks", "handballs", "marks", "tackles", "hitouts", "freeKicksFor", "clearances", "inside50s"]) totals[key] += row[key];
 }
 });
 const per = (key) => totals[key] / totals.teams;
 assert.ok(per("points") > 65 && per("points") < 125, `points ${per("points")}`);
 const handballShare = totals.handballs / (totals.handballs + totals.kicks);
 assert.ok(handballShare > 0.25 && handballShare < 0.45, `handball share ${handballShare}`);
 assert.ok(per("marks") > 60 && per("marks") < 120, `marks ${per("marks")}`);
 assert.ok(per("tackles") > 35 && per("tackles") < 90, `tackles ${per("tackles")}`);
 assert.ok(per("hitouts") > 12 && per("hitouts") < 60, `hitouts ${per("hitouts")}`);
 assert.ok(per("freeKicksFor") > 10 && per("freeKicksFor") < 40, `free kicks ${per("freeKicksFor")}`);
 assert.ok(per("clearances") > 25 && per("clearances") < 55, `clearances ${per("clearances")}`);
 assert.ok(per("inside50s") > 35 && per("inside50s") < 75, `inside 50s ${per("inside50s")}`);
});