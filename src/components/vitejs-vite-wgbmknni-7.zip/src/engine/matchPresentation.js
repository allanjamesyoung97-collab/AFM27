import { actionTiming } from './liveMatchPacing.js';
import { runningProfile, runFootballer } from './footballMotion.js';
// Presentation uses resolved events; it never rolls additional match outcomes.
// A mark only gets a distance (and a "goes back to line up") when it is within shooting range.
export const SHOOTING_RANGE_METRES = 60;
export function describePlay({ phase, kind, actor, receiver, defender, score, turnover, distance, inside50 = false, seed = 0 }) {
  const choose = (lines) => lines[Math.abs(seed) % lines.length];
  if (turnover) return choose([`${defender} cuts it off. The ball changes hands.`, `${actor} can't find a teammate — ${defender} gathers for the opposition.`, `${defender} reads the play and wins it back.`]);
  if (phase === 5) {
    const result = score === 'Goal' ? choose(['Straight through the middle!', 'Splits the big sticks!', 'Makes no mistake. Goal!']) : score === 'Behind' ? choose(['Just wide. One behind.', 'Pushes it across the face. A minor score.', 'Off target. One point.']) : score === 'Miss' ? 'Misses everything and is out on the full. No score.' : 'Falls short — the ball is still alive.';
    return `${actor} kicks from ${distance} metres. ${result}`;
  }
  if (kind === 'carry') return choose([`${actor} takes the space in front and carries.`, `${actor} breaks clear and runs on.`, `${actor} keeps possession and advances.`]);
  if (kind === 'handball') return choose([`${actor} gives the handball to ${receiver}.`, `${actor} releases by hand to ${receiver}.`, `${actor} finds ${receiver} with a handball.`]);
  if (kind === 'kick') return inside50
    ? choose([`${actor} kicks inside 50 to ${receiver}.`, `${actor} sends the ball into the forward 50.`, `${actor} drives an entry towards ${receiver}.`])
    : choose([`${actor} kicks to ${receiver}.`, `${actor} finds ${receiver} by foot.`, `${actor} sends it forward to ${receiver}.`]);
  if (phase === 4 && !(Number(distance) <= SHOOTING_RANGE_METRES)) return choose([`${actor} takes a clean mark.`, `${actor} marks it.`, `${actor} grabs the mark.`]);
  return choose([
    [`${actor} gets first hands on it at the stoppage.`, `${actor} gathers at the contest.`, `${actor} wins the loose ball.`],
    [`${actor} bursts clear of the congestion.`, `${actor} finds a way out of the pack.`, `${actor} drives the ball out of the contest.`],
    [`${actor} carries through the corridor.`, `${actor} links up through the middle.`, `${actor} takes the game on through the wing.`],
    [`${actor} sends it deep inside fifty.`, `${actor} looks for a lead inside the arc.`, `${actor} delivers into the forward line.`],
    [`${actor} takes the mark, ${distance} metres out. Goes back to line up.`, `${actor} holds the mark! A set shot from ${distance} metres.`, `${actor} marks on the lead, ${distance} metres from goal.`],
  ][phase] ?? [`${actor} has possession.`]);
}

export function separatePlayers(points) {
  const result = points.map(p => ({ ...p }));
  // Separate both teams in screen space so opponents never hide one another.
  // Use a slightly smaller minimum so contesters can stay close without
  // being shoved apart unrealistically.
  const minSep = 2.0;
  for (let pass = 0; pass < 6; pass++) for (let i = 0; i < result.length; i++) for (let j = i + 1; j < result.length; j++) {
    const a = result[i], b = result[j];
    let dx = b.x-a.x, dy = (b.y-a.y)*.65;
    const distance = Math.hypot(dx,dy);
    if (distance >= minSep) continue;
    if (distance < .001) { dx = i % 2 ? 1 : -1; dy = .5; }
    const length = Math.hypot(dx,dy), shift = (minSep-distance)/2;
    a.x -= dx/length*shift; b.x += dx/length*shift;
    a.y -= dy/length*shift/.65; b.y += dy/length*shift/.65;
  }
  return result;
}

// One physical scale for the oval, shot locations and the 50-metre arcs.
export const METRES_PER_X = 160 / 90;
export const METRES_PER_Y = METRES_PER_X * .65;
export function shotLocation(distance, left = false, angle = 0) {
  return [left ? 5 + distance * Math.cos(angle) / METRES_PER_X : 95 - distance * Math.cos(angle) / METRES_PER_X,
    50 + distance * Math.sin(angle) / METRES_PER_Y];
}
export function distanceToGoal(point, left = false) {
  return Math.hypot((point[0] - (left ? 5 : 95)) * METRES_PER_X, (point[1] - 50) * METRES_PER_Y);
}
export function moveTowards(start, end, maximum) {
  const dx = end.x-start.x, dy = (end.y-start.y)*.65;
  const distance = Math.hypot(dx,dy);
  const fraction = distance ? Math.min(1,Math.max(0,maximum)/distance) : 0;
  return { ...end, x:start.x+(end.x-start.x)*fraction, y:start.y+(end.y-start.y)*fraction };
}

// How tightly the field collapses around the ball. Pull is how much a player's
// target moves from the shifted formation toward their role spot around the
// ball; approach is how much of the gap they close each action.
export const SPACING = {
  shift: .85, maxShift: 42, compressY: .55, goalSide: 3,
  pullNear: .9, pullMid: .7, pullFar: .45, pullOuter: .2,
  approachNear: .75, approachMid: .6, approachFar: .45, approachOuter: .25,
};

// Players move for the game time an action actually takes (a kick is several
// seconds of play), not just its animation time. Without this the field cannot
// keep up with the ball and handball options never appear. Capped so a long
// action cannot teleport anyone.
export const MAX_MOVEMENT_SECONDS = 6;
export function movementSeconds(action) {
  const animated = actionTiming(action).duration / 1000;
  const played = Number(action?.seconds);
  return Number.isFinite(played) && played > animated ? Math.min(MAX_MOVEMENT_SECONDS, played) : animated;
}

// Continuous team movement: the formation shifts with the ball instead of
// pulling players back to fixed anchors. Forwards lead into space, teammates
// provide width and outlets, defenders hold structure and recover, and nearby
// players converge on contests. No snap-back after disposal.
export function planOvalMovement(entries, previousPositions, ballTarget, action, anchors, reversed = false) {
  const points = entries.map(({side, slot, player}) => {
    const id = String(player.id), anchor = anchors[slot] ?? [50,50];
    const flip = side === 'home' ? reversed : !reversed;
    const home = {x: flip ? 100-anchor[0] : anchor[0], y: anchor[1]};
    return {...runningProfile(player), id, side, slot, name:player.name, home, direction:flip ? -1 : 1,
      speed:previousPositions.get(id)?.speed ?? 0, heading:previousPositions.get(id)?.heading,
      x:previousPositions.get(id)?.x ?? home.x, y:previousPositions.get(id)?.y ?? home.y};
  });
  const ball = {x:ballTarget[0],y:ballTarget[1]};
  const metres = (a,b) => Math.hypot((a.x-b.x)*METRES_PER_X,(a.y-b.y)*METRES_PER_Y);
  const defenders = points.filter(p => p.side !== action?.side).sort((a,b)=>metres(a,ball)-metres(b,ball));
  const presserId = defenders[0]?.id;
  const coverIds = new Set(defenders.slice(1,3).map(p=>p.id));
  const attackers = points.filter(p => p.side === action?.side).sort((a,b)=>metres(a,ball)-metres(b,ball));
  const supportIds = new Set(attackers.filter(p=>p.id!==String(action?.playerId)).slice(0,2).map(p=>p.id));
  const ballUpTargets = new Map();
  if (action?.ballUp) {
    // A real ball-up: the rucks contest at the mark; four inside midfielders from each side ring it at about 6 m,
    // alternating around the circle; the next four hold a second ring at about 14 m for the spill. Everyone else keeps
    // their structure (collapse() below). Players take the slot nearest the side of the ball they are already on.
    const around = (r, angle) => ({ x: Math.max(8, Math.min(92, ball.x + r * Math.cos(angle) / METRES_PER_X)), y: Math.max(10, Math.min(90, ball.y + r * Math.sin(angle) / METRES_PER_Y)) });
    for (const side of ['home', 'away']) {
      const team = points.filter(p => p.side === side).sort((a,b)=>metres(a,ball)-metres(b,ball));
      const ruck = team.filter(p => /^(?:R|RR|RUC|RUCK)$/.test(String(p.slot).toUpperCase()))
        .sort((a,b)=>metres(a,ball)-metres(b,ball))[0] ?? team[0];
      const direction = side === 'home' ? -1 : 1;
      if (ruck) ballUpTargets.set(ruck.id, { x: Math.max(8,Math.min(92,ball.x+direction*1.8)), y: ball.y });
      const rest = team.filter(p => p.id !== ruck?.id);
      for (const [ring, radius, count] of [[0, 6, 4], [1, 14, 4]]) {
        const group = rest.splice(0, count);
        const offset = (side === 'home' ? 0 : Math.PI / count) + ring * Math.PI / (2 * count) + .4;
        const slotAngles = group.map((_, k) => offset + k * 2 * Math.PI / count);
        const angleOf = p => Math.atan2((p.y - ball.y) * METRES_PER_Y, (p.x - ball.x) * METRES_PER_X);
        const ordered = group.slice().sort((a, b) => angleOf(a) - angleOf(b));
        const sortedSlots = slotAngles.map(angle => ((angle + Math.PI) % (2 * Math.PI)) - Math.PI).sort((a, b) => a - b);
        ordered.forEach((p, k) => ballUpTargets.set(p.id, around(radius, sortedSlots[k])));
      }
    }
  }
  // Rank every player on a side by distance to the ball. The nearest ranks
  // collapse onto the contest as role-based outlets (forwards ahead, backs
  // behind, midfielders either side); outer ranks keep a shifted, compressed
  // shape. This is what puts handball options within reach of the carrier.
  const rankOf = new Map();
  for (const side of ['home', 'away']) {
    points.filter(p => p.side === side).sort((a,b)=>metres(a,ball)-metres(b,ball)).forEach((p,i)=>rankOf.set(p.id,i));
  }
  const roleOffset = p => /^(FF|CHF)/.test(p.slot) ? [24,11] : /^(FP|HF)/.test(p.slot) ? [16,14]
    : /^(FB|CHB)/.test(p.slot) ? [-12,11] : /^(BP|HB)/.test(p.slot) ? [-9,15] : /^W[12]$/.test(p.slot) ? [4,21] : [2,9];
  const collapse = (p, attackDirection) => {
    const rank = rankOf.get(p.id) ?? 17;
    const lane = p.home.y < 42 ? -1 : p.home.y > 58 ? 1 : (p.y < ball.y ? -1 : 1);
    const fx = p.home.x + Math.max(-SPACING.maxShift, Math.min(SPACING.maxShift, (ball.x-50)*SPACING.shift));
    const fy = ball.y + (p.home.y-ball.y)*SPACING.compressY;
    const [along, across] = roleOffset(p);
    const rx = ball.x + attackDirection*along/METRES_PER_X, ry = ball.y + lane*across/METRES_PER_Y;
    const w = rank <= 5 ? SPACING.pullNear : rank <= 9 ? SPACING.pullMid : rank <= 13 ? SPACING.pullFar : SPACING.pullOuter;
    return { x: fx*(1-w)+rx*w, y: fy*(1-w)+ry*w };
  };
  const approachFor = p => {
    const rank = rankOf.get(p.id) ?? 17;
    return rank <= 5 ? SPACING.approachNear : rank <= 9 ? SPACING.approachMid : rank <= 13 ? SPACING.approachFar : SPACING.approachOuter;
  };
  const wanted = new Map();
  const carrierId = String(action?.playerId);
  if (!(action?.reset && !action?.ballUp) && !action?.ballUp) {
    // Attacking side first, so defenders can pick up the attackers' outlets.
    for (const p of attackers) {
      if (p.id === carrierId) { wanted.set(p.id, { tx: ball.x, ty: ball.y, approach: .86 }); continue; }
      if (supportIds.has(p.id)) {
        const lane = p.home.y < 42 ? -1 : p.home.y > 58 ? 1 : 0;
        wanted.set(p.id, { tx: ball.x - p.direction*(8+Math.abs(lane)*2), ty: ball.y + (lane || (p.id.localeCompare(carrierId)<0?-1:1))*11, approach: .62 });
        continue;
      }
      const spot = collapse(p, p.direction);
      if (/^(FP|FF|HF|CHF)/.test(p.slot)) {
        const nearestOpponent = defenders.slice().sort((a,b)=>metres(a,p)-metres(b,p))[0];
        if (nearestOpponent && metres(nearestOpponent,p) < 22) { spot.y += (p.y<=nearestOpponent.y?-1:1)*5/METRES_PER_Y*METRES_PER_X*.65; spot.x += p.direction*4/METRES_PER_X; }
      }
      wanted.set(p.id, { tx: spot.x, ty: spot.y, approach: approachFor(p) });
    }
    // Defenders: presser on the ball, others goal-side of the nearest unmatched attacker.
    const open = attackers.filter(p => p.id !== carrierId).map(p => ({ id: p.id, ...wanted.get(p.id), direction: p.direction }));
    for (const p of defenders) {
      if (p.id === presserId && !action?.mark) { wanted.set(p.id, { tx: ball.x+p.direction*2, ty: ball.y+(p.home.y > 50 ? 1 : -1)*2, approach: .62 }); continue; }
      if (action?.mark && coverIds.has(p.id)) { wanted.set(p.id, { tx: ball.x-p.direction*10, ty: ball.y+(p.home.y > 50 ? 1 : -1)*12, approach: .62 }); continue; }
      let best = -1, bestMetres = Infinity;
      open.forEach((a, i) => { const m = metres(p, {x:a.tx,y:a.ty}); if (m < bestMetres) { bestMetres = m; best = i; } });
      if (best >= 0) {
        const mate = open.splice(best,1)[0];
        wanted.set(p.id, { tx: mate.tx + mate.direction*SPACING.goalSide/METRES_PER_X, ty: mate.ty + (p.y < mate.ty ? -1 : 1)*1.5/METRES_PER_Y, approach: Math.max(approachFor(p), Math.min(.6, mate.approach ?? 0)) });
      } else {
        const spot = collapse(p, p.direction);
        wanted.set(p.id, { tx: spot.x, ty: spot.y, approach: approachFor(p) });
      }
    }
  }
  const targets = points.map(p => {
    if (action?.reset && !action?.ballUp) return {...p,tx:p.home.x,ty:p.home.y};
    if (action?.ballUp) {
      const target = ballUpTargets.get(p.id);
      if (target) return {...p, tx:target.x, ty:target.y};
      const spot = collapse(p, p.direction);
      return {...p, tx:spot.x, ty:spot.y};
    }
    const goal = wanted.get(p.id);
    const approach = goal.approach;
    return {...p,tx:p.x*(1-approach)+goal.tx*approach,ty:p.y*(1-approach)+goal.ty*approach};
  });
  const moved = targets.map(p => {
    let tx=p.tx, ty=p.ty;
    // Teammates provide space instead of stacking in the same receiving lane.
    for (const teammate of targets) {
      if (teammate===p || teammate.side!==p.side) continue;
      const gap=metres({x:tx,y:ty},{x:teammate.tx,y:teammate.ty});
      if (gap>=9) continue;
      const side=p.id.localeCompare(teammate.id)<0?-1:1;
      ty += side*(9-gap)/METRES_PER_Y*.55;
    }
    const next=runFootballer(p,{...p,x:Math.max(7,Math.min(93,tx)),y:Math.max(8,Math.min(92,ty))},movementSeconds(action));
    const radius=Math.hypot((next.x-50)/44,(next.y-50)/42);
    return radius>1 ? {...next,x:50+(next.x-50)/radius,y:50+(next.y-50)/radius} : next;
  });
  // Open play: a forward only gets goal-side of the last defender when he is the one with the ball. This keeps the
  // forward line level with the defence instead of running out the back (rare in a real game, rarer still early on).
  if (!action?.reset && !action?.ballUp && action?.side) {
    const attackDirection = (points.find(p => p.side === action.side)?.direction) ?? 1;
    const defenders = moved.filter(p => p.side !== action.side);
    const lastLine = Math.max(...defenders.map(p => p.x * attackDirection));
    const limit = lastLine + 1.5 / METRES_PER_X;
    for (const p of moved) {
      if (p.side !== action.side || p.id === carrierId) continue;
      if (p.x * attackDirection > limit) p.x = limit * attackDirection;
    }
  }
  return action?.reset ? moved : separatePlayers(moved);
}

// Shot outcomes use the same location and physical distance as the oval.
export function resolveSpatialShot(score, origin, left, skill=70, random=Math.random) {
  const distance=distanceToGoal(origin,left);
  const angle=Math.atan2(Math.abs((origin[1]-50)*METRES_PER_Y),Math.max(1,Math.abs(origin[0]-(left?5:95))*METRES_PER_X));
  const range=40+Math.max(0,Math.min(99,skill))*.25;
  const short=distance>range ? Math.min(.85,(distance-range)/20) : 0;
  const goal=Math.max(.08,Math.min(.96,.98-distance*.009-angle*.24+(skill-70)*.003));
  const roll=random();
  if(roll<short) return {...score,text:'Short'};
  if(roll<short+(1-short)*goal) return {...score,goals:score.goals+1,total:score.total+6,text:'Goal'};
  return {...score,behinds:score.behinds+1,total:score.total+1,text:'Behind'};
}

export function floatedBallPosition(from, to, fraction) {
  const t = Math.max(0, Math.min(1, fraction));
  // Blend linear and smoothstep so the ball keeps moving between consecutive
  // actions instead of slowing to a stop at the end of every pass.
  const eased = t*.6 + t*t*(3-2*t)*.4;
  const distance = Math.hypot(to[0]-from[0], (to[1]-from[1])*.65);
  return {
    x: from[0] + (to[0]-from[0])*eased,
    y: from[1] + (to[1]-from[1])*eased,
    lift: Math.sin(Math.PI*t) * Math.min(18, 4 + distance*.22),
  };
}


export const OVAL_SLOTS = {
  FP1:[85,34], FF:[91,50], FP2:[85,66], HF1:[74,32], CHF:[74,50], HF2:[74,68],
  W1:[50,22], C:[50,50], W2:[50,78], RR:[47,43], R:[50,47], ROV:[47,57],
  HB1:[26,32], CHB:[26,50], HB2:[26,68], BP1:[15,34], FB:[9,50], BP2:[15,66],
};

// Resolve the first, deliberately small passage in field coordinates. Each
// target is a real on-field teammate within kicking range. The clearance is
// carried out of the centre, the next link uses a midfielder or wing, and the
// entry looks for a forward inside 50. The opening sequence holds together
// as a vertical slice; the match engine still resolves the shot from its
// actual location and the kicker's ability.
const metresBetween = (a,b) => Math.hypot((a.x-b.x)*METRES_PER_X,(a.y-b.y)*METRES_PER_Y);

// Who wins the ball at a stoppage, kick-in or rebound. The nearest player is not enough: a key forward
// standing in the forward 50 would collect every chain that dies there. Each line of the team has an
// affinity for loose balls, adjusted by where on the ground the ball is, then weighted by distance so
// midfielders still win the ball in the middle and defenders win it deep in defence.
const slotRole = (row) => String(row.fieldSlot ?? row.matchPosition ?? row.player?.positions?.[0] ?? '').toUpperCase().replace(/[12]$/, '');
const STOPPAGE_AFFINITY = [
  [/^(?:MID|C|RR|ROV|FOL)$/, 1], [/^(?:WING|W)$/, .55], [/^(?:RUC|RUCK|R)$/, .3],
  [/^(?:HB|HBF)$/, .5], [/^CHB$/, .25], [/^(?:FB|BP|KPD|DEF)$/, .12],
  [/^(?:HF|HFF|CHF)$/, .3], [/^(?:FP|FF|KPF|FWD)$/, .12],
];
export function chooseStoppageCollector(rows, positions, origin, attacksLeft, random = Math.random, weightOf = () => 1) {
  const candidates = rows.filter(row => row.onField && positions.has(String(row.playerId)));
  if (!candidates.length) return null;
  const goalDistance = distanceToGoal(origin, attacksLeft);
  const deepDefence = goalDistance > 115, forwardZone = goalDistance < 50;
  const weights = candidates.map(row => {
    const role = slotRole(row);
    let affinity = STOPPAGE_AFFINITY.find(([pattern]) => pattern.test(role))?.[1] ?? .3;
    if (deepDefence && /^(?:FB|BP|KPD|DEF|CHB)$/.test(role)) affinity *= 5;
    else if (deepDefence && /^(?:HB|HBF)$/.test(role)) affinity *= 2.5;
    if (forwardZone && /^(?:HF|HFF|CHF|FP|FF|KPF|FWD)$/.test(role)) affinity *= 2.5;
    const distance = metresBetween(positions.get(String(row.playerId)), { x: origin[0], y: origin[1] });
    // Reach falls away fast: a player 20 m from a loose ball is a long shot, one 40 m away almost never wins it.
    return Math.max(.0000001, affinity * weightOf(row) / (1 + (distance / 9) ** 3) / (1 + Math.max(0, Number(row.disposals ?? 0) - 12) / 5));
  });
  let roll = random() * weights.reduce((sum, value) => sum + value, 0);
  return candidates.find((row, index) => (roll -= weights[index]) <= 0) ?? candidates.at(-1);
}