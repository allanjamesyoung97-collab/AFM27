import test from "node:test";
import assert from "node:assert/strict";
import { players } from "../data/players.js";
import { createAssistantTeamSelection } from "./teamSelectionEngine.js";
import { simulateMatchEvents } from "./matchSimEngine.js";
import { advanceWithEngine, createEngineHandle } from "./liveEngineAdapter.js";
import { actionTiming } from "./liveMatchPacing.js";
import { LIVE_MATCH_STAT_KEYS } from "./liveMatchActionStats.js";
import { DEFAULT_TACTICS } from "./tacticsEngine.js";
import {
  auditMatchRules, boundaryProjection, ovalRatio, outOfBoundsChance, maxBackwardMetres, MAX_STATIONARY_HOLD_MS, isGatedRestart,
} from "./matchRules.js";

const lineupFor = (club) => {
  const squad = players.filter((player) => player.club === club);
  const selected = createAssistantTeamSelection(squad).selectedSide;
  return Object.entries(selected).filter(([, name]) => name)
    .map(([position, name]) => ({ position, player: squad.find((player) => player.name === name) }));
};

test("rule 1: the ball only leaves play by travelling to the line", () => {
  for (const point of [[50, 50], [20, 30], [80, 70], [50, 10]]) assert.ok(Math.abs(ovalRatio(boundaryProjection(point)) - 1) < 1e-9);
  // A kick aimed in the middle of the ground can never go out; one aimed at the wing can.
  assert.equal(outOfBoundsChance(0.7, [40, 50], [50, 50]), 0);
  assert.ok(outOfBoundsChance(0.7, [40, 80], [50, 88]) > 0.3);
  // And no kick flies further than a kick can.
  assert.equal(outOfBoundsChance(0.7, [8, 50], [92, 90]), 0);
});

test("rule 2: backward limits tighten toward goal and are looser for handballs", () => {
  assert.ok(maxBackwardMetres("KICK", "F50") < maxBackwardMetres("KICK", "D50"));
  assert.ok(maxBackwardMetres("KICK", "F50") <= 8);
});

test("rules 1-3: simulated matches break no rule", () => {
  const pairs = [["Essendon", "Collingwood"], ["Geelong", "Sydney"], ["Brisbane", "Carlton"]];
  pairs.forEach(([home, away], index) => {
    const { events } = simulateMatchEvents({ seed: 2000 + index, home: { name: home, lineup: lineupFor(home).filter((e) => !e.position.startsWith("INT")) }, away: { name: away, lineup: lineupFor(away).filter((e) => !e.position.startsWith("INT")) } });
    const audit = auditMatchRules(events);
    assert.deepEqual(audit.violations, [], JSON.stringify(audit.counts));
  });
});

test("the audit does catch the original bugs", () => {
  const base = { v: 1, quarter: 1, side: "home", t: 10, clock: 1190, duration: 0, outcome: "RETAINED", tags: [], statChanges: [] };
  // home attack right in Q1 (x increases toward goal): a 40m kick backwards from the forward 50
  const retreat = { ...base, seq: 0, type: "KICK", from: [85, 50], to: [50, 50], distance: 62 };
  assert.ok(auditMatchRules([retreat]).counts.RETREAT_IN_ATTACK);
  // the ball is placed outside the painted oval, with no flight
  const dragged = { ...base, seq: 0, type: "KICK", from: [50, 50], to: [33, 94], distance: 0, outcome: "OUT_OF_BOUNDS" };
  const counts = auditMatchRules([dragged]).counts;
  assert.ok(counts.BALL_OUTSIDE_BOUNDARY && counts.BALL_DRAGGED);
});

// ---- the adapter and pacing (rules 4 and 5) ------------------------------------
const helpers = {
  quarterSeconds: 1200, quarterLabels: ["First quarter", "Second quarter", "Third quarter", "Fourth quarter"],
  formatQuarterClock: (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(Math.floor(s % 60)).padStart(2, "0")}`,
  summarizeTeamStats: (rows) => ({ disposals: rows.reduce((sum, row) => sum + row.disposals, 0) }),
};
const statRows = (lineup) => lineup.map(({ player, position }) => ({
  player, onField: !position.startsWith("INT"), playerId: player.id, playerName: player.name, club: player.club,
  timeOnGround: 0, minutesPlayed: 0, ...Object.fromEntries(LIVE_MATCH_STAT_KEYS.map((key) => [key, 0])),
}));

test("rule 4: only centre bounces gate play; ball-ups, throw-ins and marks never hold it", () => {
  assert.ok(isGatedRestart("CENTRE_BOUNCE"));
  assert.ok(!isGatedRestart("BALL_UP") && !isGatedRestart("THROW_IN"));
  const homeLineup = lineupFor("Essendon");
  const awayLineup = lineupFor("Collingwood");
  let match = {
    homeTeam: "Essendon", awayTeam: "Collingwood", homeScore: 0, awayScore: 0, homeGoals: 0, homeBehinds: 0, awayGoals: 0, awayBehinds: 0,
    quarter: 1, minute: 0, elapsedSeconds: 0, secondsRemaining: 1200, possession: 50, momentum: 0, intensity: 58, tactics: DEFAULT_TACTICS,
    managerSide: "home", events: [], actions: [], scoreEvents: [], status: "LIVE", engineMode: true, engineSeed: 8, homeStrength: 0, awayStrength: 0,
    playerStats: { home: statRows(homeLineup), away: statRows(awayLineup) },
  };
  const options = { handle: createEngineHandle(), homeLineup, awayLineup, helpers };
  const seen = { ballUp: 0, throwIn: 0, mark: 0, centre: 0 };
  for (let guard = 0; guard < 4000 && match.status !== "FULL_TIME"; guard += 1) {
    if (match.status === "QUARTER_BREAK") { match = { ...match, status: "LIVE", quarter: match.quarter + 1, secondsRemaining: 1200, ballSequence: null, spatialQuarter: null }; continue; }
    match = advanceWithEngine(match, options);
    const type = match.eventLog.at(-1)?.type;
    const action = match.visualAction;
    if (type === "CENTRE_BOUNCE") { seen.centre += 1; assert.equal(action.kind, "setup"); }
    else if (type === "BALL_UP" || type === "THROW_IN") { seen[type === "BALL_UP" ? "ballUp" : "throwIn"] += 1; assert.notEqual(action.kind, "setup", `${type} must not gate play`); }
    else if (action.kind !== "setup") {
      if (action.mark || action.freeKick) { seen.mark += 1; assert.ok(actionTiming(action).duration <= MAX_STATIONARY_HOLD_MS, "a mark must not freeze play"); }
      if (action.kind === "gather") assert.ok(actionTiming(action).duration <= MAX_STATIONARY_HOLD_MS);
    }
  }
  assert.ok(seen.ballUp > 5 && seen.throwIn > 0 && seen.mark > 20 && seen.centre > 4, JSON.stringify(seen));
});

test("rule 5: positions the oval draws come straight from the engine state", () => {
  const homeLineup = lineupFor("Essendon");
  const awayLineup = lineupFor("Collingwood");
  let match = {
    homeTeam: "Essendon", awayTeam: "Collingwood", homeScore: 0, awayScore: 0, homeGoals: 0, homeBehinds: 0, awayGoals: 0, awayBehinds: 0,
    quarter: 1, minute: 0, elapsedSeconds: 0, secondsRemaining: 1200, possession: 50, momentum: 0, intensity: 58, tactics: DEFAULT_TACTICS,
    managerSide: "home", events: [], actions: [], scoreEvents: [], status: "LIVE", engineMode: true, engineSeed: 9, homeStrength: 0, awayStrength: 0,
    playerStats: { home: statRows(homeLineup), away: statRows(awayLineup) },
  };
  const options = { handle: createEngineHandle(), homeLineup, awayLineup, helpers };
  for (let i = 0; i < 400 && match.status === "LIVE"; i += 1) {
    match = advanceWithEngine(match, options);
    if (match.visualAction.kind !== "setup") assert.equal(match.spatialPositions, match.engine.state.positions);
  }
});