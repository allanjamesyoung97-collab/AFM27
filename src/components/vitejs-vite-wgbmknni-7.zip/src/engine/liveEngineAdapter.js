// Adapter between the seeded match engine and the Match Centre's `match` object.
//
// Match Centre calls advanceWithEngine(current, options) wherever it would
// otherwise resolve one possession action. The adapter steps the engine, queues
// the schema events a step produces, and turns ONE event per call into the
// fields the screen already reads: score, player stats, the action log, the
// animation (`visualAction`, `spatialPositions`), commentary, and the clock.
//
// It is a pure function of (current, options): the engine's JSON state, the
// pending event queue and the full event log all live on `current.engine` and
// `current.eventLog`, so saving and resuming a match works. Only the engine
// context (constant lineups and tactics) is cached on a handle.
import { buildMatchContext, createMatchState, stepMatch, reconcileLineup } from "./matchSimEngine.js";
import { onFieldEntries, selectRotationsForMinutes, interchangeAllowance } from "./interchange.js";
import { getPlayingPosition } from "./statisticsEngine.js";
import { applyActionStatChanges } from "./liveMatchActionStats.js";
import { selectedSideStrength } from "./tacticalMatchModel.js";
import { DEFAULT_TACTICS } from "./tacticsEngine.js";
import { OVAL_SLOTS, METRES_PER_X, METRES_PER_Y } from "./matchPresentation.js";
import { isGatedRestart } from "./matchRules.js";
import { MATCH_MARK_HOLD_MS } from "./liveMatchPacing.js";

export const ADAPTER_VERSION = 1;
const SIDES = ["home", "away"];
const other = (side) => (side === "home" ? "away" : "home");
const LEGACY_SCORE = { GOAL: "Goal", BEHIND: "Behind", MISS: "Miss", SHORT: "Short" };
const LEGACY_KIND = {
  CENTRE_BOUNCE: "gather", BALL_UP: "gather", THROW_IN: "gather", KICK_IN: "kick", GATHER: "gather", CARRY: "carry",
  HANDBALL: "handball", KICK: "kick", MARK: "mark", SPOIL: "gather", INTERCEPT: "gather", TACKLE: "turnover",
  FREE_KICK: "gather", SHOT: "shot",
};
// Match rule 4 (FLOW): only a centre bounce holds play while the oval arranges the teams (matchRules.GATED_RESTARTS).
// A ball-up or boundary throw-in is an ordinary action: players run to the contest while play continues.
const FLOW_END_TYPES = new Set(["QUARTER_END", "FULL_TIME"]);
const INTERCHANGE_CHECK_SECONDS = 120;
const MANUAL_SUB_LOCKOUT_MINUTES = 10;

/** Holds the cached engine context between calls. Keep one per Match Centre. */
export const createEngineHandle = () => ({ signature: null, fitness: null, ctx: null, liveKey: null, live: null });


// The entries on the ground now, after interchange rotations and the manager's substitutions.
const liveEntriesFor = (current, side, lineup) => {
  const manager = current.managerSide ?? "home";
  const substitutions = side === manager ? (current.substitutions ?? []).slice(current.matchupSubstitutionStart ?? 0) : [];
  return onFieldEntries(lineup, current.rotations, substitutions);
};
// The lineup on the ground only changes when the rotations, substitutions or lineups do, so reuse it between ticks.
const liveLineups = (handle, current, homeLineup, awayLineup) => {
  const key = [current.rotations, current.substitutions, current.matchupSubstitutionStart, current.managerSide, homeLineup, awayLineup];
  if (handle.liveKey && handle.liveKey.every((value, index) => value === key[index])) return handle.live;
  handle.liveKey = key;
  handle.live = { home: liveEntriesFor(current, "home", homeLineup), away: liveEntriesFor(current, "away", awayLineup) };
  return handle.live;
};

const NO_FITNESS = Object.freeze({});
function contextFor(handle, current, { homeLineup, awayLineup, playerFitness = NO_FITNESS }) {
  const manager = current.managerSide ?? "home";
  const tactics = { [manager]: current.tactics ?? DEFAULT_TACTICS, [other(manager)]: current.oppositionTactics ?? DEFAULT_TACTICS };
  const live = liveLineups(handle, current, homeLineup, awayLineup);
  const signature = JSON.stringify([
    live.home.map((entry) => [entry.position, entry.player.id]), live.away.map((entry) => [entry.position, entry.player.id]),
    tactics.home, tactics.away, current.homeStrength, current.awayStrength, current.instructions ?? {},
    // Fitness is compared by value for the players involved: the caller may hand over a new object every render.
    [...live.home, ...live.away].map((entry) => { const f = playerFitness?.[entry.player.id]; return `${f?.fitness ?? ""}/${f?.matchSharpness ?? ""}`; }),
  ]);
  if (handle.ctx && handle.signature === signature) return { ctx: handle.ctx, changed: false };
  const build = (side) => ({
    name: side === "home" ? current.homeTeam : current.awayTeam,
    lineup: live[side],
    tactics: tactics[side],
    strength: selectedSideStrength(side === "home" ? current.homeStrength ?? 0 : current.awayStrength ?? 0, live[side], playerFitness),
  });
  handle.ctx = buildMatchContext({ home: build("home"), away: build("away"), instructions: current.instructions ?? {}, fitness: playerFitness });
  handle.signature = signature;
  handle.fitness = playerFitness;
  return { ctx: handle.ctx, changed: true, live };
}

/** Row flags (on the ground, slot, position) follow the rotations. */
function syncRows(playerStats, live) {
  return Object.fromEntries(SIDES.map((side) => {
    const bySlot = new Map(live[side].map((entry) => [String(entry.player.id), entry]));
    return [side, playerStats[side].map((row) => {
      const entry = bySlot.get(String(row.playerId));
      if (!entry) return row.onField ? { ...row, onField: false } : row;
      const matchPosition = getPlayingPosition(entry.player, entry.position);
      return row.onField && row.fieldSlot === entry.position && row.matchPosition === matchPosition
        ? row : { ...row, onField: true, fieldSlot: entry.position, matchPosition, positions: [matchPosition] };
    })];
  }));
}

const legacyActionRecord = (event, protectedZone) => ({
  id: event.seq + 1, quarter: event.quarter, second: event.t, side: event.side, actorId: event.actorId, receiverId: event.receiverId,
  defenderId: event.opponentId, kind: LEGACY_KIND[event.type] ?? "gather", freeKick: event.type === "FREE_KICK", protectedZone,
  from: event.from, to: event.to, distance: event.distance ?? 0,
  score: event.type === "SHOT" ? LEGACY_SCORE[event.outcome] ?? null : null, statChanges: event.statChanges, text: event.text,
});

/** The animation action the oval reads for this event. */
function visualFor(event, { protectedZone, scorerName, scoringClub, setupId }) {
  if (isGatedRestart(event.type)) {
    return { id: setupId, kind: "setup", phase: -1, target: event.to ?? [50, 50], text: event.text };
  }
  const failed = event.outcome === "TURNOVER" && (event.type === "KICK" || event.type === "HANDBALL" || event.type === "KICK_IN");
  const base = {
    id: event.seq + 1, kind: LEGACY_KIND[event.type] ?? "gather", travelDistance: event.distance ?? 0, freeKick: false, protectedZone: null,
    target: event.to ?? event.from, carrying: false, phase: 2, distance: event.shot?.goalDistance ?? 0, mark: false, turnover: failed,
    side: failed ? other(event.side) : event.side, playerId: failed ? event.opponentId : event.receiverId ?? event.actorId,
    opponentId: failed ? event.actorId : event.opponentId, score: null, scorerName: undefined, scoringClub: undefined, text: event.text,
  };
  switch (event.type) {
    case "SHOT":
      return { ...base, kind: "shot", phase: 5, playerId: event.actorId, target: event.from, score: LEGACY_SCORE[event.outcome] ?? "Miss", scorerName, scoringClub,
        // The side the ball leaves on is decided once, by the engine, so the restart that follows is taken from the same place.
        missSign: event.shot?.missSide === "left" ? -1 : 1 };
    case "MARK":
      return { ...base, kind: "mark", mark: true, phase: 4, playerId: event.actorId, protectedZone, holdMs: MATCH_MARK_HOLD_MS };
    case "FREE_KICK":
      return { ...base, freeKick: true, phase: 0, playerId: event.actorId, protectedZone, holdMs: MATCH_MARK_HOLD_MS, startFrom: event.from };
    case "CARRY":
      return { ...base, carrying: true, playerId: event.actorId };
    case "KICK_IN":
      // A kick-in is a kick: the ball leaves the goal square and ends with the receiver, not with the kicker.
      return { ...base, phase: 2, startFrom: event.from, playerId: failed ? event.opponentId : event.receiverId ?? event.actorId, outOfBounds: event.outcome === "OUT_OF_BOUNDS" };
    case "GATHER":
      return { ...base, phase: 0, playerId: failed ? event.opponentId : event.actorId };
    case "TACKLE": case "SPOIL": case "INTERCEPT":
      return { ...base, playerId: event.actorId, opponentId: event.opponentId };
    case "KICK":
      return { ...base, phase: (event.tags ?? []).includes("INSIDE_50") ? 3 : 2, outOfBounds: event.outcome === "OUT_OF_BOUNDS" };
    default:
      return base;
  }
}

/** Formation positions for a centre bounce, with the time the oval needs to reach them. */
function setupFormation(ctx, event, previous, quarter) {
  const reversed = quarter % 2 === 0;
  const previousMap = new Map(Object.entries(previous ?? {}));
  const points = ctx.spatialEntries.map(({ side, slot, player }) => {
    const anchor = OVAL_SLOTS[slot] ?? [50, 50];
    const flip = side === "home" ? reversed : !reversed;
    const old = previousMap.get(String(player.id));
    return { ...old, id: String(player.id), side, slot, name: player.name, x: flip ? 100 - anchor[0] : anchor[0], y: anchor[1], speed: 0 };
  });
  const duration = Math.max(2500, ...points.map((point) => {
    const from = previousMap.get(point.id) ?? point;
    return 2000 + Math.hypot((point.x - from.x) * METRES_PER_X, (point.y - from.y) * METRES_PER_Y) / Math.max(5, point.maxSpeed ?? 7.5) * 1000;
  }));
  return { positions: Object.fromEntries(points.map((point) => [point.id, point])), duration };
}

const clampLead = (value) => Math.max(-15, Math.min(15, value));

/** Apply one engine event to the match. */
function applyEvent(current, event, engine, ctx, helpers) {
  const { formatQuarterClock, quarterLabels, summarizeTeamStats } = helpers;
  const managerSide = current.managerSide ?? "home";
  const finished = event.type === "FULL_TIME";
  const quarterEnded = event.type === "QUARTER_END" || finished;
  const quarter = current.quarter;
  const secondsRemaining = quarterEnded ? 0 : event.clock;
  const teamOf = (side) => (side === "home" ? current.homeTeam : current.awayTeam);

  // Stats come from the event's own deltas, exactly as the audit expects.
  let playerStats = applyActionStatChanges(current.playerStats, { statChanges: event.statChanges }, current.playerStats);
  if (event.duration > 0) {
    playerStats = Object.fromEntries(SIDES.map((side) => [side, playerStats[side].map((row) => {
      if (!row.onField) return row;
      const minutesPlayed = Number(row.minutesPlayed ?? 0) + event.duration / 60;
      return { ...row, minutesPlayed, timeOnGround: Math.round(minutesPlayed / 80 * 100) };
    })]));
  }

  const scoreEvents = [...(current.scoreEvents ?? [])];
  const isScore = event.type === "SHOT" && (event.outcome === "GOAL" || event.outcome === "BEHIND");
  const scorerRow = isScore ? playerStats[event.side].find((row) => String(row.playerId) === String(event.actorId)) : null;
  if (isScore) {
    scoreEvents.push({
      id: `score-${event.seq}`, quarter: `Q${quarter}`, clock: formatQuarterClock(helpers.quarterSeconds - secondsRemaining),
      type: LEGACY_SCORE[event.outcome], club: teamOf(event.side), playerId: event.actorId, playerName: scorerRow?.playerName,
      homeScore: event.score.home.total, awayScore: event.score.away.total,
    });
  }

  const lead = event.score.home.total - event.score.away.total;
  const timeInFront = { ...(current.timeInFront ?? { home: 0, away: 0 }) };
  if (lead > 0) timeInFront.home += event.duration; else if (lead < 0) timeInFront.away += event.duration;
  const biggestLead = { ...(current.biggestLead ?? { home: 0, away: 0 }) };
  biggestLead.home = Math.max(biggestLead.home, lead);
  biggestLead.away = Math.max(biggestLead.away, -lead);

  const possessionSeconds = engine.state.possessionSeconds;
  const totalPossession = possessionSeconds.home + possessionSeconds.away;
  const managerPossession = totalPossession > 0 ? possessionSeconds[managerSide] / totalPossession * 100 : 50;
  const teamMatch = { ...current, scoreEvents, timeInFront, biggestLead, possession: managerPossession, managerSide };
  const teamStats = Object.fromEntries(SIDES.map((side) => [side, summarizeTeamStats(playerStats[side], teamMatch, side)]));

  const visible = !FLOW_END_TYPES.has(event.type);
  const protectedZone = (event.type === "MARK" || event.type === "FREE_KICK") && engine.state.protectedZone
    && String(engine.state.protectedZone.kickerId) === String(event.actorId) ? engine.state.protectedZone : null;
  let spatial = {};
  let visualAction = current.visualAction;
  let actions = current.actions ?? [];
  let spatialPositions = current.spatialPositions;
  if (visible) {
    const setup = isGatedRestart(event.type) ? setupFormation(ctx, event, current.spatialPositions ?? engine.state.positions, quarter) : null;
    visualAction = visualFor(event, {
      protectedZone, scorerName: scorerRow?.playerName, scoringClub: teamOf(event.side), setupId: `setup-${event.seq}`,
    });
    if (setup) visualAction = { ...visualAction, duration: setup.duration };
    spatialPositions = setup ? setup.positions : engine.state.positions;
    spatial = { spatialQuarter: quarter, spatialPositions, needsCentreSetup: false, needsBallUpSetup: false, spatialBall: event.to ?? event.from ?? [50, 50] };
    actions = [...actions, legacyActionRecord(event, protectedZone)];
  }

  const commentary = [];
  if (visible && event.text) commentary.push({ id: `event-${event.seq}`, minute: Math.min(80, Math.floor(event.t / 60)), quarter: `Q${quarter}`, text: event.text, clock: formatQuarterClock(secondsRemaining), side: event.side });
  if (quarterEnded) commentary.push({ id: `end-${event.seq}`, minute: Math.min(80, Math.floor(event.t / 60)), quarter: `Q${quarter}`, text: `End of ${quarterLabels[quarter - 1]}` });

  return {
    ...current,
    ...spatial,
    actions,
    eventLog: [...(current.eventLog ?? []), event],
    visualAction,
    ballSequence: null,
    minute: Math.min(80, Math.floor(event.t / 60)),
    elapsedSeconds: Math.min(80 * 60, event.t),
    secondsRemaining,
    quarter,
    homeGoals: event.score.home.goals, homeBehinds: event.score.home.behinds, homeScore: event.score.home.total,
    awayGoals: event.score.away.goals, awayBehinds: event.score.away.behinds, awayScore: event.score.away.total,
    possession: managerPossession,
    momentum: clampLead((current.momentum ?? 0) * 0.9 + (isScore ? (event.side === "home" ? 2 : -2) : 0)),
    status: finished ? "FULL_TIME" : quarterEnded ? "QUARTER_BREAK" : "LIVE",
    ...(finished ? { matchTimeOnGround: Object.fromEntries([...playerStats.home, ...playerStats.away].map((row) => [String(row.playerId), row.timeOnGround])) } : {}),
    playerStats, teamStats, scoreEvents, timeInFront, biggestLead, traitActivations: { ...(engine.state.traitActivations ?? {}) },
    homePossessionSeconds: possessionSeconds.home,
    events: [...(current.events ?? []), ...commentary].slice(-40),
  };
}

/**
 * Advance the match by one visible event.
 * @param current the Match Centre `match` (status must be LIVE)
 * @param options { handle, homeLineup, awayLineup, playerFitness, helpers: {
 *   formatQuarterClock, quarterLabels, quarterSeconds, summarizeTeamStats }, seed? }
 */
export function advanceWithEngine(current, options) {
  if (current.status !== "LIVE") return current;
  const { handle, helpers } = options;
  const { ctx, changed } = contextFor(handle, current, options);
  let engine = current.engine ?? null;
  if (!engine) {
    const seed = current.engineSeed ?? options.seed ?? 1;
    let fresh = createMatchState({ seed, ctx });
    if (Number(current.elapsedSeconds) > 0) {
      // A match started before the engine became the only one: carry on from its quarter and score.
      fresh = { ...fresh, status: "QUARTER_BREAK", quarter: Math.max(0, (current.quarter ?? 1) - 1), elapsed: Math.max(0, ((current.quarter ?? 1) - 1) * ctx.quarterSeconds),
        score: { home: { goals: current.homeGoals ?? 0, behinds: current.homeBehinds ?? 0, total: current.homeScore ?? 0 }, away: { goals: current.awayGoals ?? 0, behinds: current.awayBehinds ?? 0, total: current.awayScore ?? 0 } } };
    }
    engine = { version: ADAPTER_VERSION, seed, state: fresh, queue: [] };
  }
  let queue = engine.queue;
  // Somebody came on, went off or changed position: the engine follows without restarting play.
  let state = changed && engine.state.stats ? reconcileLineup(engine.state, ctx) : engine.state;
  let working = current;
  if (changed) {
    working = { ...working, playerStats: current.playerStats ? syncRows(current.playerStats, liveLineups(handle, current, options.homeLineup, options.awayLineup)) : current.playerStats };
  }
  let guard = 0;
  while (!queue.length && state.status !== "FULL_TIME" && guard++ < 200) {
    const result = stepMatch(state, ctx);
    state = result.state;
    queue = [];
    for (const event of result.events) {
      // A quarter start has nothing to show, but it stays in the log so sequence numbers are unbroken.
      if (event.type === "QUARTER_START") working = { ...working, eventLog: [...(working.eventLog ?? []), event] };
      else queue.push(event);
    }
  }
  if (!queue.length) return { ...working, engine: { ...engine, state, queue }, status: "FULL_TIME" };

  let [event, ...rest] = queue;
  const primary = event;
  const upcoming = rest.filter((item) => !FLOW_END_TYPES.has(item.type));
  let next = applyEvent(working, event, { ...engine, state }, ctx, helpers);
  // A quarter or match end that follows an action is applied with it, so the break starts on the same tick.
  let endedBy = null;
  while (rest.length && FLOW_END_TYPES.has(rest[0].type)) {
    [event, ...rest] = rest;
    endedBy = event.type;
    next = applyEvent(next, event, { ...engine, state }, ctx, helpers);
  }
  next = rotateInterchange(next, primary, { endedBy, upcoming, state, options });
  return { ...next, engine: { ...engine, state, queue: rest } };
}

/** Interchange windows: quarter breaks, the set shot after a mark, stoppages and play near the bench. */
function rotateInterchange(match, primary, { endedBy, upcoming, state, options }) {
  const allowance = interchangeAllowance(primary, { quarterEnded: Boolean(endedBy), finished: endedBy === "FULL_TIME" });
  if (allowance === 0 || !match.playerStats) return match;
  // Deciding who should come off is the dearest thing the adapter does, and the answer only moves with the clock:
  // look at it about every two minutes of game time, and always at a quarter break.
  if (!endedBy && Number(match.elapsedSeconds) - Number(match.interchangeCheckedAt ?? -Infinity) < INTERCHANGE_CHECK_SECONDS) return match;
  match = { ...match, interchangeCheckedAt: Number(match.elapsedSeconds) };
  const manager = match.managerSide ?? "home";
  const protectedIds = new Set([primary, ...upcoming].flatMap((item) => [item.actorId, item.receiverId, item.opponentId]).concat([state.next?.carrierId])
    .filter((id) => id !== undefined && id !== null).map(String));
  const elapsedMinutes = Math.min(80, Number(match.elapsedSeconds ?? 0) / 60);
  const plan = match.plannedTimeOnGround ?? options.togMap ?? {};
  const substitutions = (side) => (side === manager ? (match.substitutions ?? []).slice(match.matchupSubstitutionStart ?? 0) : []);
  // A player the manager has just taken off is not sent straight back on by the automatic rotation.
  const unavailableIds = new Set((match.substitutions ?? []).filter((sub) => elapsedMinutes - Number(sub.elapsedMinutes ?? sub.minute ?? 0) < MANUAL_SUB_LOCKOUT_MINUTES)
    .map((sub) => String(sub.outgoingId)));
  const rotations = {
    ...(match.rotations ?? {}),
    ...selectRotationsForMinutes(options.homeLineup, match.playerStats.home, match.rotations, elapsedMinutes, manager === "home" ? plan : {}, substitutions("home"), { maxChanges: allowance, protectedIds, unavailableIds }),
    ...selectRotationsForMinutes(options.awayLineup, match.playerStats.away, match.rotations, elapsedMinutes, manager === "away" ? plan : {}, substitutions("away"), { maxChanges: allowance, protectedIds, unavailableIds }),
  };
  const changed = Object.keys(rotations).some((id) => rotations[id] !== match.rotations?.[id]);
  if (!changed) return match;
  const withRotations = { ...match, rotations };
  const live = { home: liveEntriesFor(withRotations, "home", options.homeLineup), away: liveEntriesFor(withRotations, "away", options.awayLineup) };
  return { ...withRotations, playerStats: syncRows(match.playerStats, live) };
}