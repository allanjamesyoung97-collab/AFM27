// Seeded, headless match engine (model v2). Plain functions: no React, no
// Math.random, no window. Every result is a schema event (see matchEvents.js),
// so a match replays from its seed and animation, commentary, statistics and
// the final score can all be derived from one log.
//
// Model: the ball is always in one of a few states (a stoppage, a loose ball,
// or a carrier holding it, possibly with a free or protected kick). A carrier
// is under a pressure level taken from the nearest defender, and chooses to
// tackle-be-tackled, shoot, run, handball or kick. A kick or handball picks a
// real teammate by distance, space and territory, is effective or not by skill
// and pressure, and a kick can be marked, contested, intercepted, spoiled or go
// out. All the numbers that shape this live in DEFAULT_TUNING.
//
// The rules this engine must keep (ball continuity, forward movement, in-on-goal,
// flow) live in matchRules.js, which also audits a finished log against them.
//
// Attributes, traits, instructions and fitness all bend the odds (see ATTRIBUTE_WEIGHTS and traitsOf); the seeded
// dice still pick the outcome. Known gaps: no injuries, no rushed behinds, and the direct opponent in a contest is
// the nearest defender rather than the matchup-model one.
import { createMatchEvent, attacksLeft as attacksLeftFor, shotGeometry, tagsFromStatChanges } from "./matchEvents.js";
import {
  OVAL_SLOTS, METRES_PER_X, METRES_PER_Y, distanceToGoal, planOvalMovement, chooseStoppageCollector, describePlay,
} from "./matchPresentation.js";
import { protectKicker, runningProfile } from "./footballMotion.js";
import { resolveLiveShot } from "./liveShotEngine.js";
import {
  DEFAULT_TACTICS, getTacticalRatings, getTacticalPhaseProfile, getTacticalRatingBonus, getTacticalDefenceBonus,
} from "./tacticsEngine.js";
import { lineMatchEffects, selectedSideStrength } from "./tacticalMatchModel.js";
import { buildMatchupModel, getMatchupSlotFamily } from "./matchupEngine.js";
import { evaluateTraitContext } from "./traitEngine.js";
import { INSTRUCTION_EFFECTS } from "./instructionEffects.js";
import { getPlayerTraitIds } from "../data/footballData.js";
import { LIVE_MATCH_STAT_KEYS } from "./liveMatchActionStats.js";
import { getSlotSuitability } from "./positionSuitability.js";
import {
  PLAYER_OVAL, ovalRatio, boundaryProjection, metresToBoundary, metresBetween as metresBetweenPoints, outOfBoundsChance, zoneOf, forwardMetres,
  maxBackwardMetres, FORCED_SHOT_METRES, OUT_OF_BOUNDS_REACH_METRES, STOPPAGE_MOVEMENT_SECONDS,
  missExitPoint, KICK_IN, OUT_ON_THE_FULL_SHARE, FLAT_CHAIN_ZONES, FLAT_DISPOSAL_METRES, MAX_FLAT_CHAIN, BREAKOUT_FORWARD_METRES,
  isFlatDisposal, kickInSpot,
} from "./matchRules.js";

// 3: speed, agility, vision, decision-making, composure and strength shape the odds (ATTRIBUTE_WEIGHTS), and a player
// id can no longer appear on both sides. Every extra roll shifts the seeded stream, so a version-2 replay differs.
export const ENGINE_VERSION = 3;
const QUARTER_SECONDS = 20 * 60;
const SIDES = ["home", "away"];
const other = (side) => (side === "home" ? "away" : "home");
const clamp = (value, low, high) => Math.max(low, Math.min(high, value));

export const DEFAULT_TUNING = {
  // pressure and tackling
  pressureRadius: 9, pressureScale: 0.65, tackleBase: 0.115, tackleHolding: 0.2, tackleBallUp: 0.26,
  // choosing a disposal
  handballBase: 0.33, handballPressure: 0.3, handballStoppage: 0.28, handballDeep: -0.14, handballForward: -0.12,
  carryProb: 0.1,
  // kick length by zone: [short, medium, long] weights
  bandsD50: [0.2, 0.35, 0.45], bandsDM: [0.25, 0.45, 0.3], bandsFM: [0.35, 0.45, 0.2], bandsF50: [0.6, 0.3, 0.1],
  // disposal efficiency
  kickEffBase: 0.79, kickEffDistance: 0.0022, kickEffPressure: 0.3, entryPenalty: 0.3,
  handballEffBase: 0.86, handballEffPressure: 0.22,
  // Inside the forward 50 the defence is set and the ball is harder to keep. The forward-only rule (matchRules) stops
  // the ball leaking out of the forward 50 through backward kicks, so these keep scoring at a realistic rate.
  f50KickPenalty: 0.3, f50HandballPenalty: 0.16,
  // marking
  markUncontested: 0.52, markContested: 0.4, contestRadius: 4.5, freeInContest: 0.02, markF50Factor: 0.55,
  // what happens after a failed disposal. outOfBounds is the chance for a kick that finishes ON the boundary and
  // falls to zero for a kick aimed well inside the ground (matchRules.outOfBoundsChance). interceptMark and
  // interceptGround are shares of the failures that stay in play; the rest are spoils.
  outOfBounds: 0.35, outOfBoundsReach: OUT_OF_BOUNDS_REACH_METRES, interceptMark: 0.225, interceptGround: 0.275,
  // Rule 7: share of out-of-bounds kicks that cross the line untouched (free kick to the opposition); the rest are
  // knocked out and become a boundary throw-in. Rule 6: how often a kick-in is run out of the square instead of kicked.
  outOnFullShare: OUT_ON_THE_FULL_SHARE, touchedOutReach: 6, kickInPlayOn: KICK_IN.PLAY_ON_CHANCE,
  // A defender only intercepts, spoils or tackles what he can reach. Past these distances the ball is loose / play is clear.
  interceptReach: 14, tackleReach: 4.5,
  // A contested ball within groundOutReach metres of the line is knocked over it this often: a boundary throw-in.
  groundOutReach: 14, groundOut: 0.4,
  // shooting. When no teammate is a legal forward option the carrier shoots out to forcedShotRange and beyond that
  // runs on (matchRules, rule 3).
  shotRange: 55, snapRange: 45, snapProb: 0.57, forcedShotRange: FORCED_SHOT_METRES,
  // loose balls and stoppages
  groundBallUp: 0.1, hitoutProb: 0.58, hitoutAdvantage: 0.62, ruckEdge: 0.004, clearanceCredit: 0.95,
  // action durations in seconds
  handballSeconds: [2.5, 1.2], kickSeconds: [3.4, 1.2, 22], carrySeconds: [3, 2], gatherSeconds: [1.6, 1.4], setShotSeconds: 6,
  // receiver choice
  progressWeight: 0.22, spaceWeight: 0.5, lateralPenalty: 0.1, targetTemp: 5,
};

// How attributes bend the odds. Every effect is (skill - 65) * coefficient, clamped, and reads its coefficient from
// here, never from an inline number. A +20 swing should move the roll it controls by about 5-8 points for a main
// attribute and 2-3 for a secondary one. Composure and decision-making act through pressure: a free player gets
// pressureFloor of the effect and a pressured one (pressureFull and above) gets all of it. gameAwareness is absorbed
// into decisionBlend, so it is not counted again beside decision-making.
export const ATTRIBUTE_WEIGHTS = {
  pressureFloor: 0.15, pressureFull: 0.5,
  decisionBlend: { decisionMaking: 0.65, gameAwareness: 0.35 },
  runBlend: { runAndCarry: 0.5, speed: 0.5 },
  decision: { eff: 0.003, temp: 0.005, tempMin: 0.6, tempMax: 1.4 },
  composure: { pressure: 0.023, min: 0.3, max: 1.5, setShot: 0.3 },
  vision: { space: 0.008, spaceMin: 0.7, spaceMax: 1.5, eff: 0.0015 },
  speed: { closeDown: 0.004, closeMin: 0.85, closeMax: 1.2, looseBall: 0.0035 },
  agility: { evade: 0.003, handball: 0.0015, looseBall: 0.001 },
  strength: { tackle: 0.002, holding: 0.002, contestedMark: 0.005, looseBall: 0.0008, ruck: 0.0005 },
};
// Per-group override: mergeWeights({ composure: { pressure: 0.01 } }) changes only that coefficient.
const mergeWeights = (override = {}) => Object.fromEntries(Object.entries(ATTRIBUTE_WEIGHTS)
  .map(([key, value]) => [key, value && typeof value === "object" ? { ...value, ...(override?.[key] ?? {}) } : (override?.[key] ?? value)]));

// ---- seeded randomness ------------------------------------------------------
export function hashSeed(seed) {
  let hash = 2166136261;
  for (const char of String(seed)) hash = Math.imul(hash ^ char.charCodeAt(0), 16777619);
  return hash >>> 0;
}

function makeRandom(state) {
  let s = state >>> 0;
  const random = () => {
    s = (s + 0x6D2B79F5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  Object.defineProperty(random, "state", { get: () => s });
  return random;
}

// ---- context: everything constant for the match ----------------------------
export function buildMatchContext({ home, away, quarterSeconds = QUARTER_SECONDS, tuning = {}, instructions = {}, fitness = {}, weights = {}, probe = null }) {
  const sides = {};
  const configs = { home, away };
  for (const side of SIDES) {
    const cfg = configs[side];
    const entries = (cfg.lineup ?? []).filter((entry) => entry?.player && entry?.position && !String(entry.position).startsWith("INT"));
    sides[side] = {
      name: cfg.name ?? side, entries, tactics: cfg.tactics ?? DEFAULT_TACTICS,
      strength: Number.isFinite(cfg.strength) ? cfg.strength : selectedSideStrength(0, entries),
    };
  }
  for (const side of SIDES) {
    const own = sides[side];
    const opp = sides[other(side)];
    own.ratings = getTacticalRatings(own.tactics);
    own.profile = getTacticalPhaseProfile(own.tactics, own.entries);
    own.attackBonus = getTacticalRatingBonus(own.tactics, own.entries);
    own.defenceBonus = getTacticalDefenceBonus(own.tactics, own.entries);
    own.matchups = buildMatchupModel(own.entries, opp.entries, {
      tactics: own.tactics, opponentTactics: opp.tactics, playerFitness: fitness,
    });
    own.line = lineMatchEffects(own.matchups);
    const goalSense = own.entries.reduce((sum, { player }) => sum + Number(player.attributes?.goalSense ?? player.overall ?? 65), 0)
      / Math.max(1, own.entries.length);
    own.scoringQuality = clamp(1 + (goalSense - 65) * 0.006, 0.78, 1.22);
  }
  // A side with better tactics and strength wins a little more of the loose ball.
  const homeEdge = (sides.home.ratings.possession - sides.away.ratings.possession) * 0.004
    + (sides.home.ratings.pressure - sides.away.ratings.pressure) * 0.0015
    + (sides.home.strength - sides.away.strength) * 0.0015;
  const spatialEntries = SIDES.flatMap((side) => sides[side].entries.map(({ position, player }) => ({ side, slot: position, player })));
  // playersById is keyed by player id, so a repeated id would resolve one side's rows to the other side's player.
  const idOwners = new Map();
  for (const entry of spatialEntries) {
    const id = String(entry.player.id);
    if (idOwners.has(id)) throw new Error(`buildMatchContext: player id "${id}" appears more than once (${idOwners.get(id)} and ${entry.side}); every player needs a distinct id`);
    idOwners.set(id, entry.side);
  }
  const playersById = new Map(spatialEntries.map((entry) => [String(entry.player.id), entry.player]));
  // Player instructions are stored by name; the engine reads their effects. Fitness and sharpness feed skill and traits.
  const instructionEffects = Object.fromEntries(Object.entries(instructions ?? {}).map(([id, name]) => [String(id), INSTRUCTION_EFFECTS[name] ?? {}]));
  return { sides, homeEdge: clamp(homeEdge, -0.1, 0.1), spatialEntries, playersById, quarterSeconds, instructions: instructionEffects, fitness: fitness ?? {}, weights: mergeWeights(weights), probe, tuning: { ...DEFAULT_TUNING, ...tuning } };
}

// ---- state ------------------------------------------------------------------
const blankRow = (player, club, slot) => ({
  playerId: player.id, playerName: player.name, club, fieldSlot: slot,
  matchPosition: getSlotSuitability(player, slot).role, onField: true,
  ...Object.fromEntries(LIVE_MATCH_STAT_KEYS.map((key) => [key, 0])),
});

export function createMatchState({ seed = 1, ctx }) {
  return {
    v: ENGINE_VERSION, seed: String(seed), rng: hashSeed(seed),
    status: "PRE", quarter: 0, elapsed: 0, secondsRemaining: ctx.quarterSeconds, seq: 0,
    score: { home: { goals: 0, behinds: 0, total: 0 }, away: { goals: 0, behinds: 0, total: 0 } },
    next: { kind: "CENTRE" }, ball: [50, 50], positions: {}, protectedZone: null, flat: null,
    possessionSeconds: { home: 0, away: 0 }, traitActivations: {},
    stats: Object.fromEntries(SIDES.map((side) => [side,
      ctx.sides[side].entries.map(({ position, player }) => blankRow(player, ctx.sides[side].name, position))])),
  };
}

/**
 * Players on the ground changed (an interchange, a substitution or a position swap). Rebuild the engine's view of who
 * is on without restarting anything: an incoming player takes the place of the player he replaced, rows follow the
 * new slots, and anything pointing at a player who left (the next carrier, a protected kicker) is passed to the
 * player who came on.
 */
export function reconcileLineup(state, ctx) {
  const positions = { ...state.positions };
  const replaced = new Map();
  const stats = {};
  for (const side of SIDES) {
    const wanted = ctx.sides[side].entries;
    const have = new Map(state.stats[side].map((row) => [String(row.playerId), row]));
    const wantedIds = new Set(wanted.map((entry) => String(entry.player.id)));
    const outgoing = state.stats[side].filter((row) => !wantedIds.has(String(row.playerId)));
    stats[side] = wanted.map(({ position, player }) => {
      const old = have.get(String(player.id));
      return old ? { ...old, fieldSlot: position, matchPosition: getSlotSuitability(player, position).role }
        : blankRow(player, ctx.sides[side].name, position);
    });
    const pool = outgoing.slice();
    for (const entry of wanted.filter((item) => !have.has(String(item.player.id)))) {
      const index = Math.max(0, pool.findIndex((row) => row.fieldSlot === entry.position));
      const donor = pool.splice(index, 1)[0];
      if (!donor) continue;
      replaced.set(String(donor.playerId), String(entry.player.id));
      if (positions[String(donor.playerId)]) positions[String(entry.player.id)] = { ...positions[String(donor.playerId)], speed: 0 };
    }
    for (const row of outgoing) delete positions[String(row.playerId)];
  }
  const swap = (id) => (id == null ? id : replaced.get(String(id)) ?? id);
  const next = { ...state.next };
  if (next.carrierId != null) next.carrierId = swap(next.carrierId);
  const zone = state.protectedZone;
  return {
    ...state, stats, positions, next,
    protectedZone: zone ? { ...zone, kickerId: swap(zone.kickerId), markerId: swap(zone.markerId) } : zone,
  };
}

const anchorPositions = (ctx, reversed) => Object.fromEntries(ctx.spatialEntries.map((entry) => {
  const anchor = OVAL_SLOTS[entry.slot] ?? [50, 50];
  const flip = entry.side === "home" ? reversed : !reversed;
  return [String(entry.player.id), { x: flip ? 100 - anchor[0] : anchor[0], y: anchor[1], speed: 0 }];
}));

const skill = (row, key) => Number(row?.player?.attributes?.[key] ?? row?.player?.overall ?? 65) + (Number(row?.sharp ?? 70) - 70) * 0.08;
const metresApart = (a, b) => Math.hypot((a.x - b.x) * METRES_PER_X, (a.y - b.y) * METRES_PER_Y);
const pt = (point) => ({ x: point[0], y: point[1] });
// A point players and the ball can use: inside the square limits and inside the oval.
const clampPoint = (point) => {
  const x = clamp(point[0], 7, 93);
  const y = clamp(point[1], 7, 93);
  const ratio = ovalRatio([x, y], PLAYER_OVAL);
  return ratio > 1 ? [PLAYER_OVAL.cx + (x - PLAYER_OVAL.cx) / ratio, PLAYER_OVAL.cy + (y - PLAYER_OVAL.cy) / ratio] : [x, y];
};

// ---- one step ---------------------------------------------------------------
export function stepMatch(prev, ctx) {
  if (prev.status === "FULL_TIME") return { state: prev, events: [] };
  const T = ctx.tuning;
  const W = ctx.weights ?? mergeWeights();
  const probe = ctx.probe;
  const random = makeRandom(prev.rng);
  const state = {
    ...prev, possessionSeconds: { ...prev.possessionSeconds }, traitActivations: { ...(prev.traitActivations ?? {}) }, next: { ...prev.next },
    stats: { home: prev.stats.home.map((r) => ({ ...r })), away: prev.stats.away.map((r) => ({ ...r })) },
  };
  const events = [];
  let pending = [];

  const rowOf = (side, id) => state.stats[side].find((r) => String(r.playerId) === String(id));
  const rowsOf = (side) => state.stats[side].map((row) => ({ ...row, player: ctx.playersById.get(String(row.playerId)), sharp: ctx.fitness?.[row.playerId]?.matchSharpness }));
  const posMap = () => new Map(Object.entries(state.positions));
  const bump = (side, id, key, n = 1) => {
    const row = rowOf(side, id);
    if (!row) return;
    row[key] += n;
    pending.push({ side, playerId: row.playerId, key, n });
  };
  const flush = () => {
    const grouped = new Map();
    for (const { side, playerId, key, n } of pending) {
      const id = `${side}:${playerId}`;
      const entry = grouped.get(id) ?? { side, playerId, stats: {} };
      entry.stats[key] = (entry.stats[key] ?? 0) + n;
      grouped.set(id, entry);
    }
    pending = [];
    return [...grouped.values()];
  };
  let stepSpent = 0;
  const spend = (seconds, side = null) => {
    // Whole milliseconds, so the clock never drifts past the end of a quarter.
    const spent = Math.round(Math.min(Math.max(0, seconds), state.secondsRemaining) * 1000) / 1000;
    state.elapsed = Math.round((state.elapsed + spent) * 1000) / 1000;
    state.secondsRemaining = Math.round((state.secondsRemaining - spent) * 1000) / 1000;
    if (side) state.possessionSeconds[side] += spent;
    stepSpent += spent;
    return spent;
  };
  const emit = (input) => {
    const statChanges = flush();
    const tags = [...new Set([...(input.tags ?? []), ...tagsFromStatChanges(statChanges)])];
    const event = createMatchEvent({
      ...input, tags, statChanges, seq: state.seq, quarter: state.quarter, t: state.elapsed, previousScore: state.score,
    });
    state.seq += 1;
    state.score = event.score;
    events.push(event);
    return event;
  };
  // Rule 8: the run of flat (sideways) disposals the side in possession has made. It survives only into a step that
  // continues the chain; every other step ends it.
  const flatBefore = prev.flat ?? null;
  let flatAfter = null;
  const finish = () => ({ state: { ...state, flat: flatAfter, rng: random.state }, events });
  const reversed = () => state.quarter % 2 === 0;
  const leftFor = (side) => attacksLeftFor(side, state.quarter);
  const weighted = (items, weightOf) => {
    const weights = items.map(weightOf);
    let roll = random() * weights.reduce((sum, w) => sum + w, 0);
    return items.find((item, i) => (roll -= weights[i]) <= 0) ?? items.at(-1);
  };
  const nearestTo = (rows, point, excludeId = null) => {
    const positions = posMap();
    let best = null;
    for (const row of rows) {
      if (excludeId !== null && String(row.playerId) === String(excludeId)) continue;
      const p = positions.get(String(row.playerId));
      if (!p) continue;
      const metres = metresApart(p, pt(point));
      if (!best || metres < best.metres) best = { row, metres };
    }
    return best;
  };
  const settle = (action, target) => {
    const moved = planOvalMovement(ctx.spatialEntries, posMap(), target, { ...action, seconds: stepSpent }, OVAL_SLOTS, reversed());
    state.positions = Object.fromEntries(protectKicker(moved, state.protectedZone).map((p) => [p.id, p]));
  };
  const name = (row) => row?.playerName ?? "A player";
  // Player instructions and traits. Both are read where the old Match Centre chain read them: tackling, disposal
  // effectiveness, marking, intercepts, scoring and who gets the ball at a stoppage.
  const NONE = {};
  const instrOf = (row) => ctx.instructions?.[String(row?.playerId)] ?? NONE;
  const mod = (result, key) => result?.modifiers?.[key] ?? 0;
  const traitCache = new Map();
  const traitsOf = (side, row, opponent, phase) => {
    if (!row?.player) return null;
    const cacheKey = `${side}:${row.playerId}:${opponent?.playerId ?? ""}:${phase}`;
    if (traitCache.has(cacheKey)) return traitCache.get(cacheKey);
    const own = ctx.sides[side];
    const pair = own.matchups?.byPlayerId?.[String(row.playerId)];
    const fit = ctx.fitness ?? {};
    const result = evaluateTraitContext(row.player, {
      phase, opponent: opponent?.player, roleFamily: pair?.line ?? getMatchupSlotFamily(row.fieldSlot),
      opponentRoleFamily: getMatchupSlotFamily(pair?.opponentSlot),
      tactics: own.tactics, opponentTactics: ctx.sides[other(side)].tactics,
      fitness: fit[row.playerId]?.fitness, matchSharpness: fit[row.playerId]?.matchSharpness,
      opponentFitness: fit[opponent?.playerId]?.fitness, opponentMatchSharpness: fit[opponent?.playerId]?.matchSharpness,
      minute: state.elapsed / 60, scoreMargin: state.score.home.total - state.score.away.total,
    });
    traitCache.set(cacheKey, result);
    for (const active of result.active ?? []) {
      const key = `${row.playerId}:${active.id}`;
      state.traitActivations[key] = (state.traitActivations[key] ?? 0) + 1;
    }
    return result;
  };
  const usageWeight = (row) => (instrOf(row).usage ?? 1) * (1 + (instrOf(row).contested ?? 0) * 2);
  // Attribute helpers; every coefficient comes from ATTRIBUTE_WEIGHTS (W).
  const blend = (row, weights) => Object.entries(weights).reduce((sum, [key, weight]) => sum + weight * skill(row, key), 0);
  const pressureWeight = (pressure) => clamp(W.pressureFloor + (1 - W.pressureFloor) * pressure / W.pressureFull, W.pressureFloor, 1);
  const decisionRating = (row) => blend(row, W.decisionBlend);
  // Composure shrinks (or, when low, grows) what pressure costs a disposal or a shot.
  const composureFactor = (row) => clamp(1 - (skill(row, "composure") - 65) * W.composure.pressure, W.composure.min, W.composure.max);
  // Agility lets a carrier slip a tackle; the stronger player wins the grapple.
  const tackleAttr = (carrier, tackler) => clamp(1 - (skill(carrier, "agility") - 65) * W.agility.evade
    + (skill(tackler, "strength") - skill(carrier, "strength")) * W.strength.tackle, 0.6, 1.4);
  const tackleProbe = (side, pressure, tackled) => { probe?.({ kind: "TACKLE", side, pressure, tackled }); return tackled; };

  // Quarter start.
  if (state.status === "PRE" || state.status === "QUARTER_BREAK") {
    state.quarter += 1;
    state.status = "LIVE";
    state.secondsRemaining = ctx.quarterSeconds;
    state.next = { kind: "CENTRE" };
    state.positions = anchorPositions(ctx, reversed());
    state.ball = [50, 50];
    state.protectedZone = null;
    emit({ type: "QUARTER_START" });
    return finish();
  }

  // ---- stoppages: centre bounce, ball-up, boundary throw-in -------------------
  const resolveStoppage = (kind) => {
    const type = kind === "CENTRE" ? "CENTRE_BOUNCE" : kind === "THROW_IN" ? "THROW_IN" : "BALL_UP";
    const rucks = {};
    for (const side of SIDES) {
      rucks[side] = rowsOf(side).find((r) => r.fieldSlot === "R" || r.matchPosition === "RUC") ?? rowsOf(side)[0];
    }
    const edge = (skill(rucks.home, "ruckCraft") - skill(rucks.away, "ruckCraft")) * T.ruckEdge
      + (skill(rucks.home, "strength") - skill(rucks.away, "strength")) * W.strength.ruck + ctx.homeEdge * 0.5;
    const tapSide = random() < clamp(0.5 + edge, 0.3, 0.7) ? "home" : "away";
    const ruck = rucks[tapSide];
    if (kind !== "CENTRE") {
      // Players run to the contest for a few game seconds while play carries on; nothing waits for them.
      const moved = planOvalMovement(ctx.spatialEntries, posMap(), state.ball, { reset: true, ballUp: true, side: tapSide, seconds: STOPPAGE_MOVEMENT_SECONDS[type] }, OVAL_SLOTS, reversed());
      state.positions = Object.fromEntries(moved.map((p) => [p.id, p]));
    }
    const hit = random() < clamp(T.hitoutProb + (instrOf(ruck).hitout ?? 0), 0.2, 0.9);
    if (hit) bump(tapSide, ruck.playerId, "hitouts");
    const clearanceKind = kind === "CENTRE" ? "CENTRE" : "STOPPAGE";
    emit({
      type, side: tapSide, actorId: ruck.playerId, from: state.ball, to: state.ball, distance: 0, outcome: "STOPPAGE",
      tags: kind === "THROW_IN" ? ["CONTESTED", "BOUNDARY"] : ["CONTESTED"],
      text: kind === "CENTRE" ? "Centre ball-up." : kind === "THROW_IN" ? "Boundary throw-in." : "Ball-up.",
    });
    if (hit && random() < T.hitoutAdvantage) {
      const left = leftFor(tapSide);
      const collector = chooseStoppageCollector(rowsOf(tapSide), posMap(), state.ball, left, random, usageWeight);
      spend(T.gatherSeconds[0] + random() * T.gatherSeconds[1], tapSide);
      emit({ type: "GATHER", side: tapSide, actorId: collector.playerId, opponentId: null, from: state.ball, to: state.ball, distance: 0,
        outcome: "RETAINED", tags: ["CENTRE_CLEARANCE", "STOPPAGE_CLEARANCE"].slice(kind === "CENTRE" ? 0 : 1, kind === "CENTRE" ? 1 : 2).filter(() => false),
        text: `${name(collector)} gets the tap and gathers.` });
      state.next = { kind: "CARRY", side: tapSide, carrierId: collector.playerId, via: "STOPPAGE", clearance: clearanceKind };
      settle({ kind: "gather", side: tapSide, playerId: String(collector.playerId) }, state.ball);
    } else {
      state.next = { kind: "GROUND", biasSide: tapSide, bias: 0.06, clearance: clearanceKind };
      settle({ kind: "gather", side: tapSide, playerId: String(ruck.playerId) }, state.ball);
    }
  };

  // ---- a loose ball: somebody wins it, or it is tied up ------------------------
  const resolveGround = () => {
    const { biasSide = null, bias = 0, clearance = null, fromSpoil = false } = state.next;
    const origin = state.ball;
    if (metresToBoundary(origin) < T.groundOutReach && random() < T.groundOut) {
      // Knocked over the line in the contest: the ball goes to the boundary and there is a throw-in.
      spend(2);
      state.ball = boundaryProjection(origin);
      state.next = { kind: "THROW_IN" };
      return;
    }
    if (random() < T.groundBallUp) {
      // Tied up in the contest: time passes, then a ball-up. No credit goes to either side.
      spend(2);
      state.next = { kind: "BALL_UP" };
      return;
    }
    const candidates = {};
    for (const side of SIDES) candidates[side] = chooseStoppageCollector(rowsOf(side), posMap(), origin, leftFor(side), random, usageWeight);
    const homeBias = (biasSide === "home" ? bias : biasSide === "away" ? -bias : 0) + ctx.homeEdge;
    const looseEdge = (key, weight) => (skill(candidates.home, key) - skill(candidates.away, key)) * weight;
    const strengthEdge = looseEdge("contestedBall", 0.003) + looseEdge("speed", W.speed.looseBall)
      + looseEdge("agility", W.agility.looseBall) + looseEdge("strength", W.strength.looseBall);
    const winnerSide = random() < clamp(0.5 + homeBias + strengthEdge, 0.25, 0.75) ? "home" : "away";
    const winner = candidates[winnerSide];
    probe?.({ kind: "LOOSE", side: winnerSide });
    bump(winnerSide, winner.playerId, "contestedPossessions");
    if (fromSpoil && winnerSide === biasSide) bump(winnerSide, winner.playerId, "intercepts");
    const loser = nearestTo(rowsOf(other(winnerSide)), origin);
    if (random() < T.freeInContest && loser) return awardFree(winnerSide, winner, loser.row, origin, "CONTEST");
    spend(T.gatherSeconds[0] + random() * T.gatherSeconds[1], winnerSide);
    emit({ type: "GATHER", side: winnerSide, actorId: winner.playerId, opponentId: loser?.row.playerId ?? null, from: origin, to: origin, distance: 0,
      outcome: "RETAINED", tags: ["CONTESTED"], text: `${name(winner)} wins the loose ball.` });
    state.next = { kind: "CARRY", side: winnerSide, carrierId: winner.playerId, via: clearance ? "STOPPAGE" : "GATHER", clearance };
    settle({ kind: "gather", side: winnerSide, playerId: String(winner.playerId), opponentId: loser?.row.playerId }, origin);
  };

  // ---- a free kick to `side` ----------------------------------------------------
  const awardFree = (side, winner, loser, origin, reason) => {
    bump(side, winner.playerId, "freeKicksFor");
    bump(other(side), loser.playerId, "freeKicksAgainst");
    const left = leftFor(side);
    const zone = zoneOf(distanceToGoal(origin, left));
    spend(1.5, side);
    const onTheFull = reason === "OUT_ON_THE_FULL";
    emit({ type: "FREE_KICK", side, actorId: winner.playerId, opponentId: loser.playerId, from: origin, to: origin, distance: 0, outcome: "RETAINED",
      tags: onTheFull ? ["BOUNDARY", "OUT_ON_THE_FULL"] : [reason === "HOLDING" ? "HOLDING_THE_BALL" : "CONTESTED", ...(zone === "F50" ? ["INSIDE_50"] : [])],
      text: onTheFull ? `Out on the full. Free kick to ${name(winner)}.`
        : reason === "HOLDING" ? `${name(winner)} tackles ${name(loser)}. Holding the ball.` : `${name(winner)} is awarded a free kick.` });
    state.ball = origin;
    state.protectedZone = { kickerId: String(winner.playerId), markerId: String(loser.playerId), side, origin, direction: left ? -1 : 1 };
    state.next = { kind: "CARRY", side, carrierId: winner.playerId, via: "FREE" };
    settle({ kind: "kick", side, playerId: String(winner.playerId), opponentId: String(loser.playerId), freeKick: true, protectedZone: state.protectedZone }, origin);
  };

  // ---- choosing a teammate ------------------------------------------------------
  const chooseReceiver = ({ attackRows, carrier, from, left, kind, zone, attack, kickIn = false, breakout = false, pressure = 0 }) => {
    const positions = posMap();
    const defendRows = rowsOf(other(carrier.side ?? state.next.side));
    const origin = pt(from);
    const maxBack = maxBackwardMetres(kind, zone);
    const minProgress = kickIn ? KICK_IN.MIN_FORWARD_METRES
      : breakout ? BREAKOUT_FORWARD_METRES
        : kind === "KICK" && FLAT_CHAIN_ZONES.has(zone) ? FLAT_DISPOSAL_METRES : -maxBack;
    const all = attackRows.filter((r) => String(r.playerId) !== String(carrier.playerId) && positions.has(String(r.playerId)))
      .map((row) => {
        const p = positions.get(String(row.playerId));
        const metres = metresApart(p, origin);
        const progress = forwardMetres(from, clampPoint([p.x, p.y]), left); // measured to where the ball would actually land
        const lateral = Math.abs(p.y - origin.y) * METRES_PER_Y;
        const nearestDef = nearestTo(defendRows, [p.x, p.y]);
        return { row, p, metres, progress, lateral, space: Math.min(18, nearestDef?.metres ?? 18) };
      })
      // RULE 2: a side with the ball moves it toward its own goal. No receiver is further back than the zone allows.
      // RULE 6: a kick-in must gain real ground. RULE 8: outside the forward half a kick must gain ground too, and after
      // a run of flat disposals the next one must break the chain.
      .filter((c) => c.progress >= minProgress && (!kickIn || c.metres <= KICK_IN.MAX_RANGE_METRES));
    let pool;
    if (kind === "HANDBALL") pool = all.filter((c) => c.metres >= 2 && c.metres <= 16);
    else {
      const ranges = [[12, 30], [28, 48], [44, 75]];
      const weights = T[`bands${zone}`];
      let band = weighted([0, 1, 2], (i) => weights[i]);
      pool = all.filter((c) => c.metres >= ranges[band][0] && c.metres <= ranges[band][1]);
      for (const alt of [1, 0, 2].filter((i) => i !== band)) {
        if (pool.length) break;
        pool = all.filter((c) => c.metres >= ranges[alt][0] && c.metres <= ranges[alt][1]);
      }
    }
    if (!pool.length) pool = all.filter((c) => c.metres >= (kind === "HANDBALL" ? 2 : 10)).sort((a, b) => a.metres - b.metres).slice(0, 4);
    if (!pool.length) return null;
    const roleBonus = (c) => {
      const slot = String(c.row.fieldSlot).replace(/[12]$/, "");
      if (kind === "KICK" && (zone === "FM" || zone === "F50") && /^(FF|CHF|FP|HF)$/.test(slot)) return 5;
      if (kind === "KICK" && (zone === "D50" || zone === "DM") && /^(HB|W|C|RR|ROV|CHB)$/.test(slot)) return 3;
      if (kind === "HANDBALL" && /^(C|RR|ROV|W|HB)$/.test(slot)) return 3;
      return 0;
    };
    // Decision-making (under pressure) sharpens the choice; vision puts more weight on finding the open teammate.
    const temperature = T.targetTemp * clamp(1 - (decisionRating(carrier) - 65) * W.decision.temp * pressureWeight(pressure), W.decision.tempMin, W.decision.tempMax);
    const spaceWeight = T.spaceWeight * clamp(1 + (skill(carrier, "vision") - 65) * W.vision.space, W.vision.spaceMin, W.vision.spaceMax);
    return weighted(pool, (c) => usageWeight(c.row) * Math.exp((c.progress * T.progressWeight * attack.transition + c.space * spaceWeight
      - c.lateral * T.lateralPenalty + roleBonus(c)) / temperature));
  };

  // ---- a possession action by the carrier --------------------------------------
  const resolveCarry = () => {
    const { side, carrierId, via = "GATHER", clearance = null } = state.next;
    const defendSide = other(side);
    const attackRows = rowsOf(side);
    const defendRows = rowsOf(defendSide);
    const carrier = attackRows.find((r) => String(r.playerId) === String(carrierId));
    if (!carrier) { state.next = { kind: "BALL_UP" }; return; }
    carrier.side = side;
    const attackCtx = ctx.sides[side];
    const defendCtx = ctx.sides[defendSide];
    const attack = attackCtx.profile;
    const left = leftFor(side);
    const origin = state.ball;
    const goalDistance = distanceToGoal(origin, left);
    const zone = zoneOf(goalDistance);
    const free = via === "FREE" || via === "MARK" || via === "KICK_IN";
    const flatCount = flatBefore?.side === side ? flatBefore.n : 0;
    const breakout = FLAT_CHAIN_ZONES.has(zone) && flatCount >= MAX_FLAT_CHAIN;
    const nearestDef = nearestTo(defendRows, origin);
    // A faster defender closes down the carrier sooner, so he applies more pressure.
    const closeDown = nearestDef ? clamp(1 + (skill(nearestDef.row, "speed") - 65) * W.speed.closeDown, W.speed.closeMin, W.speed.closeMax) : 1;
    const pressure = free ? 0 : clamp((1 - (nearestDef?.metres ?? 20) / T.pressureRadius) * T.pressureScale * defendCtx.profile.pressure * closeDown, 0, 0.9);

    // Tackle.
    if (!free && nearestDef && nearestDef.metres <= T.tackleReach && tackleProbe(side, pressure, random() < pressure * T.tackleBase * clamp(1 + (skill(nearestDef.row, "tackling") - 65) * 0.01, 0.7, 1.3) * 4
      * tackleAttr(carrier, nearestDef.row)
      * clamp(1 + ((instrOf(nearestDef.row).tackle ?? 0) + mod(traitsOf(defendSide, nearestDef.row, carrier, "transition"), "tackle")) / 0.2, 0.5, 2.5))) {
      const tackler = nearestDef.row;
      bump(defendSide, tackler.playerId, "tackles");
      if (distanceToGoal(origin, leftFor(defendSide)) <= 50) bump(defendSide, tackler.playerId, "tacklesInside50");
      const roll = random();
      spend(2, side);
      const holding = clamp(T.tackleHolding + (skill(tackler, "strength") - skill(carrier, "strength")) * W.strength.holding, 0.05, 0.45);
      if (roll < holding) {
        bump(side, carrier.playerId, "turnovers");
        emit({ type: "TACKLE", side: defendSide, actorId: tackler.playerId, opponentId: carrier.playerId, from: origin, to: origin, distance: 0,
          outcome: "TURNOVER", tags: ["HOLDING_THE_BALL"], text: `${name(tackler)} wraps up ${name(carrier)}.` });
        return awardFree(defendSide, tackler, carrier, origin, "HOLDING");
      }
      if (roll < holding + T.tackleBallUp) {
        emit({ type: "TACKLE", side: defendSide, actorId: tackler.playerId, opponentId: carrier.playerId, from: origin, to: origin, distance: 0,
          outcome: "STOPPAGE", tags: [], text: `${name(tackler)} ties up ${name(carrier)}. Ball-up.` });
        state.next = { kind: "BALL_UP" };
        return;
      }
      bump(side, carrier.playerId, "turnovers");
      emit({ type: "TACKLE", side: defendSide, actorId: tackler.playerId, opponentId: carrier.playerId, from: origin, to: origin, distance: 0,
        outcome: "TURNOVER", tags: ["CONTESTED"], text: `${name(tackler)} tackles and the ball spills loose.` });
      state.next = { kind: "GROUND", biasSide: defendSide, bias: 0.12 };
      return;
    }

    // Shot. RULE 3: a player in on goal shoots.
    const set = via === "MARK" || via === "FREE";
    const shootNow = () => resolveShot({ side, carrier, defendSide, defender: nearestDef?.row, origin, left, set, pressure, attackCtx, defendCtx });
    if (goalDistance <= T.shotRange) {
      const p = set ? (goalDistance <= 30 ? 0.97 : goalDistance <= 45 ? 0.92 : 0.7)
        : goalDistance <= T.snapRange ? T.snapProb * (1 - pressure * 0.4) : 0;
      if (random() < p) return shootNow();
    }

    // Run with the ball, always toward goal.
    const runWithBall = () => {
      const advance = (6 + random() * 14) * (blend(carrier, W.runBlend) / 65);
      const to = clampPoint([origin[0] + (left ? -1 : 1) * advance / METRES_PER_X, origin[1] + (random() - 0.5) * 6]);
      if (random() < 0.15 + (instrOf(carrier).bounce ?? 0)) bump(side, carrier.playerId, "bounces");
      spend(T.carrySeconds[0] + random() * T.carrySeconds[1], side);
      emit({ type: "CARRY", side, actorId: carrier.playerId, opponentId: nearestDef?.row.playerId ?? null, from: origin, to, distance: Math.round(metresBetweenPoints(origin, to)),
        outcome: "RETAINED", tags: [], text: `${name(carrier)} runs with the ball.` });
      state.ball = to;
      state.next = { kind: "CARRY", side, carrierId: carrier.playerId, via: "RUN", clearance };
      settle({ kind: "carry", side, playerId: String(carrier.playerId), opponentId: nearestDef?.row.playerId }, to);
    };
    if (!free && random() < T.carryProb * (1 - pressure) * (blend(carrier, W.runBlend) / 65)) return runWithBall();

    // Rule 6: a kick-in is sometimes run out of the square (play on) instead of kicked.
    if (via === "KICK_IN" && random() < T.kickInPlayOn) return runWithBall();

    // Disposal.
    const handballProb = via === "KICK_IN" ? 0
      : clamp(T.handballBase + pressure * T.handballPressure + (clearance ? T.handballStoppage : 0)
        + (zone === "D50" ? T.handballDeep : 0) + (zone === "F50" ? T.handballForward : 0), 0.04, 0.85);
    let kind = random() < handballProb ? "HANDBALL" : "KICK";
    const kickIn = via === "KICK_IN";
    let receiver = chooseReceiver({ attackRows, carrier, from: origin, left, kind, zone, attack, kickIn, breakout, pressure });
    if (!receiver && kind === "HANDBALL") { kind = "KICK"; receiver = chooseReceiver({ attackRows, carrier, from: origin, left, kind, zone, attack, kickIn, breakout, pressure }); }
    if (!receiver) {
      // RULES 2 and 3: nobody is a legal forward option. He has a shot, or he runs on; he does not go backwards.
      if (goalDistance <= T.forcedShotRange) return shootNow();
      return runWithBall();
    }
    const target = clampPoint([receiver.p.x, receiver.p.y]);
    const metres = receiver.metres;
    const enters = distanceToGoal(target, left) <= 50 && goalDistance > 50;
    const rebounds = distanceToGoal(origin, !left) <= 50 && distanceToGoal(target, !left) > 50;
    const actorTraits = traitsOf(side, carrier, nearestDef?.row, enters ? "forwardEntry" : clearance ? "stoppage" : "transition");
    const defTraits = nearestDef ? traitsOf(defendSide, nearestDef.row, carrier, goalDistance <= 50 ? "defensiveContest" : "transition") : null;
    const actorInstr = instrOf(carrier);
    const defInstr = nearestDef ? instrOf(nearestDef.row) : NONE;
    const fieldGeneral = attackRows.some((r) => String(r.playerId) !== String(carrier.playerId)
      && Number(ctx.fitness?.[r.playerId]?.fitness ?? 100) >= 65 && getPlayerTraitIds(r.player).includes("FIELD_GENERAL")) ? 0.01 : 0;
    const skillBoost = mod(actorTraits, "effectiveDisposal") + mod(defTraits, "opponentEffectiveDisposal")
      + (actorInstr.effective ?? 0) + (defInstr.opponentEffectiveDisposal ?? 0) + fieldGeneral - (free ? 0 : (defInstr.tag ?? 0))
      + (enters ? mod(actorTraits, "inside50") + (actorInstr.inside50 ?? 0) : 0);
    const composure = composureFactor(carrier);
    const decisionEff = (decisionRating(carrier) - 65) * W.decision.eff * pressureWeight(pressure);
    const efficiency = kind === "KICK"
      ? clamp(T.kickEffBase - T.kickEffDistance * Math.max(0, metres - 25) - T.kickEffPressure * pressure * composure
        + (skill(carrier, "kicking") - 65) * 0.004 + decisionEff + (skill(carrier, "vision") - 65) * W.vision.eff
        + (attack.retention - 1) * 0.3 + skillBoost - (enters ? T.entryPenalty : 0) - (goalDistance <= 50 ? T.f50KickPenalty : 0), 0.3, 0.96)
      : clamp(T.handballEffBase - T.handballEffPressure * pressure * composure + (skill(carrier, "handball") - 65) * 0.003 + decisionEff
        + (skill(carrier, "agility") - 65) * W.agility.handball * pressureWeight(pressure) + skillBoost - (goalDistance <= 50 ? T.f50HandballPenalty : 0), 0.5, 0.98);
    const effective = random() < efficiency;
    probe?.({ kind: "DISPOSAL", disposal: kind, side, playerId: carrier.playerId, pressure, effective, efficiency, entering: enters });
    // RULE 1: only a kick whose flight carries it over the line can go out of bounds.
    const outOfBounds = !effective && kind === "KICK" && random() < outOfBoundsChance(T.outOfBounds, origin, target, T.outOfBoundsReach);
    const seconds = kind === "KICK" ? T.kickSeconds[0] + metres / T.kickSeconds[2] + random() * T.kickSeconds[1] : T.handballSeconds[0] + random() * T.handballSeconds[1];

    bump(side, carrier.playerId, "disposals");
    bump(side, carrier.playerId, kind === "KICK" ? "kicks" : "handballs");
    if (effective) bump(side, carrier.playerId, "effectiveDisposals");
    if (enters && !outOfBounds) bump(side, carrier.playerId, "inside50s");
    if (effective && rebounds) bump(side, carrier.playerId, "rebound50s");
    if (clearance && random() < T.clearanceCredit + (actorInstr.clearance ?? 0) + mod(actorTraits, "clearance") + mod(defTraits, "opponentClearance")) {
      bump(side, carrier.playerId, "clearances");
      bump(side, carrier.playerId, clearance === "CENTRE" ? "centreClearances" : "stoppageClearances");
    }
    state.protectedZone = null;
    spend(seconds, side);
    const baseTags = enters && !outOfBounds ? ["INSIDE_50"] : [];
    const type = via === "KICK_IN" ? "KICK_IN" : kind;
    const common = { type, side, actorId: carrier.playerId, receiverId: receiver.row.playerId, opponentId: nearestDef?.row.playerId ?? null,
      from: origin, to: target, distance: Math.round(metres) };
    const text = describePlay({ phase: 2, kind: kind.toLowerCase(), actor: name(carrier), receiver: name(receiver.row), inside50: enters, seed: Math.floor(state.elapsed * 10) });

    if (effective) {
      flatAfter = FLAT_CHAIN_ZONES.has(zone) && isFlatDisposal(forwardMetres(origin, target, left)) ? { side, n: flatCount + 1 } : null;
      emit({ ...common, duration: seconds, outcome: "RETAINED", tags: baseTags, text });
      state.ball = target;
      const receiverRow = receiver.row;
      if (kind === "KICK") {
        const targetNear = nearestTo(defendRows, target);
        const contested = (targetNear?.metres ?? 99) < T.contestRadius;
        const markSkill = skill(receiverRow, "marking");
        const inF50 = distanceToGoal(target, left) <= 50;
        const f50 = inF50 ? T.markF50Factor : 1;
        const receiverInstr = instrOf(receiverRow);
        const markBoost = mod(traitsOf(side, receiverRow, targetNear?.row, "aerialContest"), "mark") + (receiverInstr.mark ?? 0) + (inF50 ? (receiverInstr.markInside50 ?? 0) : 0)
          + (targetNear ? mod(traitsOf(defendSide, targetNear.row, receiverRow, "defensiveContest"), "opponentMark") + (instrOf(targetNear.row).opponentMark ?? 0) : 0);
        const marked = random() < f50 * (contested ? clamp(T.markContested + (markSkill - skill(targetNear?.row, "marking")) * 0.005
          + (skill(receiverRow, "strength") - skill(targetNear?.row, "strength")) * W.strength.contestedMark + markBoost, 0.15, 0.7)
          : clamp(T.markUncontested + (markSkill - 65) * 0.003 + markBoost - (metres > 50 ? 0.1 : 0), 0.3, 0.85));
        probe?.({ kind: "MARK", side, contested, marked });
        if (marked) {
          bump(side, receiverRow.playerId, "marks");
          if (contested) { bump(side, receiverRow.playerId, "contestedMarks"); bump(side, receiverRow.playerId, "contestedPossessions"); }
          if (distanceToGoal(target, left) <= 50) bump(side, receiverRow.playerId, "marksInside50");
          if (contested && targetNear && random() < T.freeInContest) {
            emit({ type: "MARK", side, actorId: receiverRow.playerId, opponentId: targetNear.row.playerId, from: target, to: target, distance: 0, outcome: "RETAINED",
              tags: contested ? ["CONTESTED"] : [], text: `${name(receiverRow)} marks.` });
            state.protectedZone = null;
            return awardFree(side, receiverRow, targetNear.row, target, "CONTEST");
          }
          spend(0.8, side);
          emit({ type: "MARK", side, actorId: receiverRow.playerId, opponentId: targetNear?.row.playerId ?? null, from: target, to: target, distance: 0,
            outcome: "RETAINED", tags: contested ? ["CONTESTED"] : [],
            text: describePlay({ phase: 4, kind: "mark", actor: name(receiverRow), distance: Math.round(distanceToGoal(target, left)), seed: Math.floor(state.elapsed * 10) }) });
          const dz = left ? -1 : 1;
          state.protectedZone = { kickerId: String(receiverRow.playerId), markerId: String(targetNear?.row.playerId ?? ""), side, origin: target, direction: dz };
          state.next = { kind: "CARRY", side, carrierId: receiverRow.playerId, via: "MARK" };
          settle({ kind: "mark", side, playerId: String(receiverRow.playerId), opponentId: targetNear?.row.playerId, mark: true, protectedZone: state.protectedZone }, target);
          return;
        }
        if (contested && targetNear) {
          // The contest is lost but the ball is still live: spoil, then a ground contest.
          bump(defendSide, targetNear.row.playerId, "onePercenters");
          emit({ type: "SPOIL", side: defendSide, actorId: targetNear.row.playerId, opponentId: receiverRow.playerId, from: target, to: target, distance: 0,
            outcome: "RETAINED", tags: ["CONTESTED"], text: `${name(targetNear.row)} spoils the mark.` });
          state.next = { kind: "GROUND", biasSide: defendSide, bias: 0.05, fromSpoil: true };
          settle({ kind: "gather", side: defendSide, playerId: String(targetNear.row.playerId) }, target);
          return;
        }
      }
      state.next = { kind: "CARRY", side, carrierId: receiver.row.playerId, via: kind === "HANDBALL" ? "HANDBALL" : "GATHER" };
      settle({ kind: kind.toLowerCase(), side, playerId: String(receiver.row.playerId), opponentId: nearestDef?.row.playerId }, target);
      return;
    }

    // Failed disposal.
    bump(side, carrier.playerId, "turnovers");
    if (!outOfBounds) emit({ ...common, duration: seconds, outcome: "TURNOVER", tags: baseTags, text });
    const defenderNear = nearestTo(defendRows, target) ?? nearestDef;
    if (outOfBounds) {
      // The ball travels to the line and crosses it: one kick, one flight, recorded as such.
      // Rule 7: untouched, it is out on the full and the opposition get a free kick where it crossed the line.
      // Otherwise a player knocked it over the line and there is a boundary throw-in.
      const exit = boundaryProjection(target);
      state.ball = exit;
      // Untouched is out on the full, a free kick. Only a defender within reach of the line can have knocked it out.
      const nearExit = nearestTo(defendRows, exit);
      const touched = Boolean(nearExit && nearExit.metres < T.touchedOutReach && random() >= T.outOnFullShare);
      const onTheFull = !touched;
      emit({ ...common, type, to: exit, distance: Math.round(metresBetweenPoints(origin, exit)), duration: seconds, outcome: "OUT_OF_BOUNDS",
        tags: onTheFull ? ["BOUNDARY", "OUT_ON_THE_FULL"] : ["BOUNDARY"],
        text: onTheFull ? `${name(carrier)}'s kick sails over the boundary. Out on the full.` : `${name(carrier)}'s kick is knocked over the boundary by ${name(nearExit.row)}.` });
      const taker = onTheFull ? nearestTo(defendRows, exit) : null;
      if (taker) return awardFree(defendSide, taker.row, carrier, exit, "OUT_ON_THE_FULL");
      state.next = { kind: "THROW_IN" };
      return;
    }
    if (!defenderNear) { state.next = { kind: "BALL_UP" }; return; }
    state.ball = target;
    if (defenderNear.metres > T.interceptReach) {
      // Nobody is near enough to touch it: it lands loose and the nearest players run to it.
      state.next = { kind: "GROUND", biasSide: defendSide, bias: 0.05 };
      settle({ kind: "gather", side: defendSide, playerId: "" }, target);
      return;
    }
    const roll = random();
    const d = defenderNear.row;
    state.ball = target;
    const interceptBoost = Math.min(1.9, 1 + (instrOf(d).intercept ?? 0) / 0.17);
    if (random() < (instrOf(d).onePercenter ?? 0)) bump(defendSide, d.playerId, "onePercenters");
    if (roll < T.interceptMark * interceptBoost && kind === "KICK") {
      bump(defendSide, d.playerId, "marks");
      bump(defendSide, d.playerId, "intercepts");
      if (defenderNear.metres < 3) bump(defendSide, d.playerId, "contestedMarks");
      spend(0.8, defendSide);
      emit({ type: "MARK", side: defendSide, actorId: d.playerId, opponentId: receiver.row.playerId, from: target, to: target, distance: 0, outcome: "RETAINED",
        tags: ["INTERCEPT", ...(defenderNear.metres < 3 ? ["CONTESTED"] : [])], text: `${name(d)} reads it and takes the intercept mark.` });
      state.protectedZone = null;
      state.next = { kind: "CARRY", side: defendSide, carrierId: d.playerId, via: "MARK" };
      settle({ kind: "mark", side: defendSide, playerId: String(d.playerId), mark: true }, target);
      return;
    }
    if (roll < Math.min(0.85, (T.interceptMark + T.interceptGround) * interceptBoost)) {
      bump(defendSide, d.playerId, "intercepts");
      spend(1, defendSide);
      emit({ type: "INTERCEPT", side: defendSide, actorId: d.playerId, opponentId: carrier.playerId, from: target, to: target, distance: 0, outcome: "RETAINED",
        tags: ["INTERCEPT"], text: `${name(d)} picks it off. Turnover.` });
      state.next = { kind: "CARRY", side: defendSide, carrierId: d.playerId, via: "GATHER" };
      settle({ kind: "gather", side: defendSide, playerId: String(d.playerId) }, target);
      return;
    }
    bump(defendSide, d.playerId, "onePercenters");
    emit({ type: "SPOIL", side: defendSide, actorId: d.playerId, opponentId: carrier.playerId, from: target, to: target, distance: 0, outcome: "RETAINED",
      tags: ["CONTESTED"], text: `${name(d)} spoils it.` });
    state.next = { kind: "GROUND", biasSide: defendSide, bias: 0.05, fromSpoil: true };
    settle({ kind: "gather", side: defendSide, playerId: String(d.playerId) }, target);
  };

  // ---- a shot at goal ---------------------------------------------------------
  const resolveShot = ({ side, carrier, defendSide, defender, origin, left, set, pressure, attackCtx, defendCtx }) => {
    const geometry = shotGeometry(origin, left);
    const attack = attackCtx.profile;
    const defend = defendCtx.profile;
    const scorerTraits = traitsOf(side, carrier, defender, "scoring");
    const shotDefenderTraits = defender ? traitsOf(defendSide, defender, carrier, "defensiveContest") : null;
    const scoringModifier = attackCtx.scoringQuality * attack.scoring * attackCtx.line.scoring
      * Math.pow(defend.pressure, -0.35) * Math.pow(defend.defence, -0.35)
      * (1 + mod(scorerTraits, "scoringRate") + mod(shotDefenderTraits, "opponentScoringRate"));
    const strengthEdge = attackCtx.strength - defendCtx.strength + attackCtx.attackBonus * 0.42 - defendCtx.defenceBonus * 0.28;
    const resolved = resolveLiveShot({ goals: 0, behinds: 0, total: 0 }, {
      distance: geometry.goalDistance, angle: geometry.angle, pressure: set ? 0 : clamp(pressure * composureFactor(carrier), 0, 1),
      goalSense: skill(carrier, "goalSense") + (set ? (skill(carrier, "composure") - 65) * W.composure.setShot : 0), scoringModifier, strengthEdge,
      instructionEffect: (instrOf(carrier).attack ?? 0) - (defender ? (instrOf(defender).defensive ?? 0) : 0),
    }, random);
    const outcome = { Goal: "GOAL", Behind: "BEHIND", Miss: "MISS", Short: "SHORT" }[resolved.text] ?? "MISS";
    probe?.({ kind: "SHOT", side, set, pressure: set ? 0 : pressure, outcome });
    bump(side, carrier.playerId, "kicks");
    bump(side, carrier.playerId, "disposals");
    if (outcome === "GOAL") { bump(side, carrier.playerId, "goals"); bump(side, carrier.playerId, "effectiveDisposals"); }
    if (outcome === "BEHIND") bump(side, carrier.playerId, "behinds");
    const shot = { ...geometry, kind: set ? "SET" : "SNAP", missSide: null };
    const tags = [set ? "SET_SHOT" : "SNAP"];
    if (outcome === "BEHIND" || outcome === "MISS") {
      shot.missSide = random() < 0.5 ? "left" : "right";
      if (outcome === "BEHIND" && random() < 0.1) tags.push("HIT_POST");
    }
    spend(set ? T.setShotSeconds : 3, side);
    state.protectedZone = null;
    emit({ type: "SHOT", side, actorId: carrier.playerId, opponentId: defender?.playerId ?? null, from: origin, to: origin, distance: 0,
      shot, outcome, tags, text: describePlay({ phase: 5, kind: "shot", actor: name(carrier), score: resolved.text, distance: geometry.goalDistance, seed: Math.floor(state.elapsed * 10) }) });
    if (outcome === "GOAL") { state.next = { kind: "CENTRE" }; state.ball = [50, 50]; return; }
    if (outcome === "SHORT") { state.next = { kind: "GROUND", biasSide: defendSide, bias: 0.12 }; settle({ kind: "gather", side: defendSide, playerId: String(defender?.playerId ?? "") }, origin); return; }
    if (outcome === "MISS") {
      // Rule 7: a shot that misses everything is out on the full. Free kick to the defender nearest the line, taken
      // from where it crossed, never from where the shot was taken.
      const exit = missExitPoint(left, shot.missSide === "left" ? -1 : 1);
      const taker = nearestTo(rowsOf(defendSide), exit);
      if (taker) return awardFree(defendSide, taker.row, carrier, exit, "OUT_ON_THE_FULL");
    }
    // Rule 6: a behind is a kick-in from the goal square.
    const spot = kickInSpot(left);
    const defenders = rowsOf(defendSide);
    const kicker = weighted(defenders, (row) => (/^(FB|BP|CHB|HB)/.test(String(row.fieldSlot)) ? 3 : 0.3));
    state.ball = spot;
    state.next = { kind: "CARRY", side: defendSide, carrierId: kicker.playerId, via: "KICK_IN" };
    settle({ kind: "kick", side: defendSide, playerId: String(kicker.playerId) }, spot);
  };

  // ---- dispatch ---------------------------------------------------------------
  const kind = state.next.kind;
  if (kind === "CENTRE") { state.ball = [50, 50]; state.positions = anchorPositions(ctx, reversed()); state.protectedZone = null; resolveStoppage("CENTRE"); }
  else if (kind === "BALL_UP") resolveStoppage("BALL_UP");
  else if (kind === "THROW_IN") resolveStoppage("THROW_IN");
  else if (kind === "GROUND") resolveGround();
  else resolveCarry();

  if (state.secondsRemaining <= 0) {
    state.status = state.quarter >= 4 ? "FULL_TIME" : "QUARTER_BREAK";
    emit({ type: state.quarter >= 4 ? "FULL_TIME" : "QUARTER_END" });
  }
  return finish();
}

/** Play a whole match headlessly. Returns the event log, final state and a summary. */
export function simulateMatchEvents({ seed = 1, home, away, quarterSeconds, tuning, instructions, fitness, weights, probe, maxSteps = 8000 }) {
  const ctx = buildMatchContext({ home, away, quarterSeconds, tuning, instructions, fitness, weights, probe });
  let state = createMatchState({ seed, ctx });
  const events = [];
  for (let i = 0; i < maxSteps && state.status !== "FULL_TIME"; i += 1) {
    const result = stepMatch(state, ctx);
    state = result.state;
    events.push(...result.events);
  }
  if (state.status !== "FULL_TIME") throw new Error(`match did not finish within ${maxSteps} steps`);
  return { events, state, ctx, score: state.score, playerStats: state.stats };
}