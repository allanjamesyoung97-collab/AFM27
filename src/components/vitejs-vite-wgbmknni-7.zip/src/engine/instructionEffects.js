// What each live player instruction does to the match. Shared by the match engine (which applies the effects) and
// the Match Centre (which lists them). Keys are the instruction names a manager picks.
export const INSTRUCTION_EFFECTS = {
  "Tag their best player": { defensive: 0.025, tackle: 0.12, tag: 0.075, target: "opposition" },
  "Pressure their exit": { opponentEffectiveDisposal: -0.035, tackle: 0.09, defensive: 0.015 },
  "Push higher": { inside50: 0.12, tackle: 0.08, defensive: -0.008 },
  "Hold position": { intercept: 0.13, onePercenter: 0.12, defensive: 0.012 },
  "Protect the corridor": { intercept: 0.16, onePercenter: 0.1, defensive: 0.03 },
  "Stay goal side": { intercept: 0.08, tackle: 0.13, defensive: 0.02 },
  "Run into space": { inside50: 0.17, bounce: 0.12, effective: 0.035 },
  "Contest hard": { contested: 0.17, clearance: 0.12, tackle: 0.1 },
  "Crumb the contest": { contested: 0.09, inside50: 0.06, attack: 0.02 },
  "Spoil the contest": { opponentMark: -0.045, onePercenter: 0.13 },
  "Lead up at the ball": { mark: 0.15, markInside50: 0.12, attack: 0.025 },
  "Attack the aerial contest": { mark: 0.12, hitout: 0.1, contested: 0.04 },
  "Rotate through the midfield": { usage: 1.35, contested: 0.06 },
};