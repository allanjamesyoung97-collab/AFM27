import test from "node:test";
import assert from "node:assert/strict";
import { players } from "../data/players.js";
import { createAssistantTeamSelection } from "./teamSelectionEngine.js";
import { buildMatchContext, createMatchState, stepMatch, simulateMatchEvents } from "./matchSimEngine.js";
import { planOvalMovement, describePlay, OVAL_SLOTS, METRES_PER_X, METRES_PER_Y, SHOOTING_RANGE_METRES } from "./matchPresentation.js";
import { resolveLiveShot } from "./liveShotEngine.js";

const lineupFor = (club) => {
  const squad = players.filter((player) => player.club === club);
  const selected = createAssistantTeamSelection(squad).selectedSide;
  return Object.entries(selected).filter(([position, name]) => name && !position.startsWith("INT"))
    .map(([position, name]) => ({ position, player: squad.find((player) => player.name === name) }));
};
const setup = () => {
  const ctx = buildMatchContext({ home: { name: "Essendon", lineup: lineupFor("Essendon") }, away: { name: "Collingwood", lineup: lineupFor("Collingwood") } });
  const state = stepMatch(createMatchState({ seed: 5, ctx }), ctx).state; // quarter start: everyone on their anchors
  return { ctx, positions: new Map(Object.entries(state.positions)) };
};
const metresTo = (point, ball) => Math.hypot((point.x - ball[0]) * METRES_PER_X, (point.y - ball[1]) * METRES_PER_Y);

test("a ball-up is a proper stoppage: both sides ring it, not just two ruckmen", () => {
  const { ctx, positions } = setup();
  const ball = [50, 50];
  const moved = planOvalMovement(ctx.spatialEntries, positions, ball, { reset: true, ballUp: true, side: "home", seconds: 6 }, OVAL_SLOTS, false);
  for (const side of ["home", "away"]) {
    const team = moved.filter((point) => point.side === side);
    assert.ok(team.filter((point) => metresTo(point, ball) < 15).length >= 5, `${side} should have at least 5 players within 15 m`);
    assert.ok(team.filter((point) => metresTo(point, ball) < 9).length >= 3, `${side} should have at least 3 players within 9 m`);
  }
});

test("open play: no forward gets behind the last defender unless he has the ball", () => {
  const { ctx, positions } = setup();
  const ball = [30, 50];
  const carrier = ctx.spatialEntries.find((entry) => entry.side === "home" && /^C/.test(entry.slot)) ?? ctx.spatialEntries.find((entry) => entry.side === "home");
  let current = positions;
  for (let step = 0; step < 6; step += 1) {
    const moved = planOvalMovement(ctx.spatialEntries, current, ball, { kind: "kick", side: "home", playerId: String(carrier.player.id), seconds: 4 }, OVAL_SLOTS, false);
    const lastLine = Math.max(...moved.filter((point) => point.side === "away").map((point) => point.x));
    for (const point of moved.filter((p) => p.side === "home" && p.id !== String(carrier.player.id))) {
      assert.ok((point.x - lastLine) * METRES_PER_X < 4, `${point.name} is ${((point.x - lastLine) * METRES_PER_X).toFixed(1)} m behind the last defender`);
    }
    current = new Map(moved.map((point) => [point.id, point]));
  }
});

test("mark commentary only quotes a distance inside shooting range", () => {
  const far = describePlay({ phase: 4, kind: "mark", actor: "A. Player", distance: 95, seed: 1 });
  assert.ok(!/metres|line up/.test(far), far);
  const near = describePlay({ phase: 4, kind: "mark", actor: "A. Player", distance: 32, seed: 1 });
  assert.match(near, /32 metres/);
  assert.ok(SHOOTING_RANGE_METRES >= 55 && SHOOTING_RANGE_METRES <= 65);
});

test("easy shots are converted: straight in front inside 15 m is close to certain, and a miss is a long-range result", () => {
  const roll = (distance, n = 6000) => {
    let seed = 7;
    const random = () => { seed = (seed * 1664525 + 1013904223) % 4294967296; return seed / 4294967296; };
    const out = { Goal: 0, Behind: 0, Miss: 0 };
    for (let i = 0; i < n; i += 1) out[resolveLiveShot({ goals: 0, behinds: 0, total: 0 }, { distance, angle: 0, pressure: 0, goalSense: 65 }, random).text] += 1;
    return Object.fromEntries(Object.entries(out).map(([key, value]) => [key, value / n]));
  };
  const close = roll(12);
  assert.ok(close.Goal >= 0.75, `goal rate at 12 m is ${close.Goal}`);
  assert.ok(close.Miss <= 0.03, `miss rate at 12 m is ${close.Miss}`);
  assert.ok(roll(25).Goal >= 0.6);
  assert.ok(roll(65).Goal <= 0.15);
});

test("engine: every untouched kick out of bounds is a free kick and counts as one in the stats", () => {
  for (const seed of [4001, 4002]) {
    const events = simulateMatchEvents({ seed, home: { name: "Essendon", lineup: lineupFor("Essendon") }, away: { name: "Collingwood", lineup: lineupFor("Collingwood") } }).events;
    let onTheFull = 0;
    events.forEach((event, i) => {
      if (event.outcome !== "OUT_OF_BOUNDS" || !(event.tags ?? []).includes("OUT_ON_THE_FULL")) return;
      const next = events[i + 1];
      if (!next || next.type === "QUARTER_END" || next.type === "FULL_TIME") return;
      onTheFull += 1;
      assert.equal(next.type, "FREE_KICK");
      const credited = (next.statChanges ?? []).some((change) => change.stats?.freeKicksFor === 1);
      assert.ok(credited, "the free kick for an out-on-the-full must be credited to the taker");
    });
    assert.ok(onTheFull > 3);
    // The ones that are NOT on the full were knocked out and say so.
    for (const event of events.filter((e) => e.outcome === "OUT_OF_BOUNDS" && !(e.tags ?? []).includes("OUT_ON_THE_FULL"))) {
      assert.match(event.text, /knocked over the boundary/);
    }
  }
});

test("engine: a miss leaves on the side the shot reports, and the free kick is taken on that side", () => {
  let checked = 0;
  for (const seed of [4003, 4004, 4005]) {
    const events = simulateMatchEvents({ seed, home: { name: "Geelong", lineup: lineupFor("Geelong") }, away: { name: "Sydney", lineup: lineupFor("Sydney") } }).events;
    events.forEach((event, i) => {
      if (event.type !== "SHOT" || event.outcome !== "MISS") return;
      const next = events[i + 1];
      if (next?.type !== "FREE_KICK") return;
      checked += 1;
      const sign = event.shot.missSide === "left" ? -1 : 1;
      assert.ok((next.from[1] - 50) * sign > 0, `miss ${event.shot.missSide} but the free kick is at y=${next.from[1].toFixed(1)}`);
    });
  }
  assert.ok(checked > 10);
});

test("instructions are read by the engine: a tackling instruction gives more tackles, a marking instruction more marks", () => {
  const home = { name: "Essendon", lineup: lineupFor("Essendon") };
  const away = { name: "Collingwood", lineup: lineupFor("Collingwood") };
  const total = (instructionName, key) => {
    const instructions = instructionName ? Object.fromEntries(home.lineup.map((entry) => [entry.player.id, instructionName])) : {};
    let sum = 0;
    for (const seed of [21, 22, 23, 24]) {
      for (const event of simulateMatchEvents({ seed, home, away, instructions }).events) {
        for (const change of event.statChanges ?? []) if (change.side === "home") sum += change.stats?.[key] ?? 0;
      }
    }
    return sum;
  };
  assert.ok(total("Stay goal side", "tackles") > total(null, "tackles") * 1.03, "a tackling instruction produces more tackles");
  assert.ok(total("Lead up at the ball", "marks") > total(null, "marks") * 1.02, "a marking instruction produces more marks");
});

test("traits fire in the engine and are counted on its state", () => {
  const ctx = buildMatchContext({ home: { name: "Essendon", lineup: lineupFor("Essendon") }, away: { name: "Collingwood", lineup: lineupFor("Collingwood") } });
  let state = createMatchState({ seed: 31, ctx });
  for (let i = 0; i < 600 && state.status !== "FULL_TIME"; i += 1) state = stepMatch(state, ctx).state;
  assert.ok(Object.keys(state.traitActivations).length > 0, "at least one trait activated");
});