// Headless calibration for the seeded match engine.
// node tools/calibrate-match-engine.mjs [matches=12] [firstSeed=1] [tuningKey=value ...]
// Prints per-team averages next to approximate AFL benchmarks so tuning has a target.
// Tuning overrides take numbers, e.g. `handballBase=0.35 tackleBase=0.12`.
//
// Sensitivity mode: node tools/calibrate-match-engine.mjs sensitivity [matches=60] [quarterSeconds=300] [only=composure,speed] [group.key=value ...]
// Essendon v Essendon with distinct player ids on each side. The home side gets +20 on ONE attribute at a time
// (decisionMaking, composure, vision, speed, agility, strength) and each row compares an action-level stat with the
// unchanged mirror match, because margin is too noisy to tune from. `group.key=value` overrides an ATTRIBUTE_WEIGHTS
// coefficient for the run, e.g. `composure.pressure=0.01`. Shorter quarters keep it quick; the stats are per action.
import { players } from "../src/data/players.js";
import { createAssistantTeamSelection } from "../src/engine/teamSelectionEngine.js";
import { simulateMatchEvents, DEFAULT_TUNING, ATTRIBUTE_WEIGHTS } from "../src/engine/matchSimEngine.js";
import { verifyEventLog } from "../src/engine/matchEvents.js";

const args = process.argv.slice(2);
// ---- sensitivity mode ---------------------------------------------------------------------------------------------
async function runSensitivity(sArgs) {
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const [matches = 60, quarterSeconds = 300] = sArgs.filter((a) => !a.includes("=")).map(Number);
  const only = (sArgs.find((a) => a.startsWith("only=")) ?? "").slice(5).split(",").filter(Boolean);
  const weights = {};
  for (const arg of sArgs.filter((a) => /^[a-zA-Z]+\.[a-zA-Z]+=/.test(a))) {
    const [path, value] = arg.split("=");
    const [group, key] = path.split(".");
    if (!(group in ATTRIBUTE_WEIGHTS) || !(key in ATTRIBUTE_WEIGHTS[group])) throw new Error(`unknown weight ${path}`);
    (weights[group] ??= {})[key] = Number(value);
  }
  const squad = players.filter((player) => player.club === "Essendon");
  const picked = createAssistantTeamSelection(squad).selectedSide;
  const base = Object.entries(picked).filter(([slot, name]) => name && !slot.startsWith("INT"))
    .map(([position, name]) => ({ position, player: squad.find((player) => player.name === name) }));
  // Distinct ids on each side: the engine looks players up by id, so a shared id would make both sides one player.
  const away = base.map(({ position, player }) => ({ position, player: { ...clone(player), id: `away_${player.id}` } }));
  const boosted = (key) => base.map(({ position, player }) => {
    const copy = clone(player);
    copy.attributes[key] = Math.min(99, Number(copy.attributes[key] ?? copy.overall ?? 65) + 20);
    return { position, player: copy };
  });

  const play = (home) => {
    const c = {};
    const add = (key, value = 1) => { c[key] = (c[key] ?? 0) + value; };
    const probe = (e) => {
      if (e.kind === "DISPOSAL") {
        const band = e.pressure >= 0.35 ? "hi" : e.pressure < 0.05 ? "free" : "mid";
        for (const tag of ["all", band]) { add(`disp.${e.side}.${tag}.n`); add(`disp.${e.side}.${tag}.p`, e.efficiency); if (e.effective) add(`disp.${e.side}.${tag}.eff`); }
      } else if (e.kind === "SHOT" && (e.outcome === "GOAL" || e.outcome === "BEHIND") && !e.set && e.pressure > 0.2) {
        add(`snap.${e.side}.n`); if (e.outcome === "GOAL") add(`snap.${e.side}.g`);
      } else if (e.kind === "TACKLE" && e.pressure >= 0.3) {
        add(`tackle.${e.side}.n`); if (e.tackled) add(`tackle.${e.side}.t`);
      } else if (e.kind === "MARK" && e.contested) {
        add(`cmark.${e.side}.n`); if (e.marked) add(`cmark.${e.side}.w`);
      } else if (e.kind === "LOOSE") add(`loose.${e.side}`);
    };
    for (let i = 0; i < matches; i += 1) {
      const result = simulateMatchEvents({ seed: 101 + i, quarterSeconds, weights, probe, home: { name: "H", lineup: home }, away: { name: "A", lineup: away } });
      add("margin", result.score.home.total - result.score.away.total);
      add("win", result.score.home.total > result.score.away.total ? 1 : result.score.home.total === result.score.away.total ? 0.5 : 0);
      for (const e of result.events) if (e.type === "CARRY" && e.side === "home") { add("run.n"); add("run.m", e.distance ?? 0); }
      for (const side of ["home", "away"]) for (const row of result.playerStats[side]) for (const key of ["intercepts", "inside50s", "clearances"]) add(`stat.${side}.${key}`, row[key] ?? 0);
    }
    return c;
  };

  const ratio = (c, num, den) => ({ v: 100 * (c[num] ?? 0) / Math.max(1, c[den] ?? 0), n: c[den] ?? 0 });
  // dir: +1 the stat should rise, -1 fall, 0 stay put. lo-hi: the wanted size of the change (points, or % for "rel").
  const ROWS = [
    ["decisionMaking", "effective disposal, all (pts, modelled)", (c) => ({ v: 100 * (c["disp.home.all.p"] ?? 0) / Math.max(1, c["disp.home.all.n"] ?? 0) }), "pts", 1, 2, 3],
    ["decisionMaking", "home kicks intercepted (%)", (c) => ({ v: c["stat.away.intercepts"] }), "rel", -1, 3, 7],
    ["composure", "effective disposal, pressured (pts, modelled)", (c) => ({ v: 100 * (c["disp.home.hi.p"] ?? 0) / Math.max(1, c["disp.home.hi.n"] ?? 0) }), "pts", 1, 4, 6],
    ["composure", "snap goal accuracy, pressured (pts)", (c) => ratio(c, "snap.home.g", "snap.home.n"), "pts", 1, 4, 5],
    ["composure", "effective disposal, free play (pts, modelled)", (c) => ({ v: 100 * (c["disp.home.free.p"] ?? 0) / Math.max(1, c["disp.home.free.n"] ?? 0) }), "pts", 0, 0, 1],
    ["vision", "home kicks intercepted (%)", (c) => ({ v: c["stat.away.intercepts"] }), "rel", -1, 5, 8],
    ["vision", "inside-50 entries (%)", (c) => ({ v: c["stat.home.inside50s"] }), "rel", 1, 3, 5],
    ["speed", "loose-ball wins, home share (pts)", (c) => ({ v: 100 * (c["loose.home"] ?? 0) / Math.max(1, (c["loose.home"] ?? 0) + (c["loose.away"] ?? 0)), n: (c["loose.home"] ?? 0) + (c["loose.away"] ?? 0) }), "pts", 1, 5, 8],
    ["speed", "metres per run (%)", (c) => ({ v: c["run.m"] / Math.max(1, c["run.n"]) }), "rel", 1, 8, 12],
    ["agility", "tackled when pressured (%)", (c) => ratio(c, "tackle.home.t", "tackle.home.n"), "rel", -1, 5, 8],
    ["strength", "contested marks won (pts)", (c) => ratio(c, "cmark.home.w", "cmark.home.n"), "pts", 1, 5, 8],
    ["strength", "clearances (%)", (c) => ({ v: c["stat.home.clearances"] }), "rel", 1, 3, 5],
  ];
  const attributes = ["decisionMaking", "composure", "vision", "speed", "agility", "strength"].filter((key) => !only.length || only.includes(key));
  const weightNote = Object.keys(weights).length ? ` weights ${JSON.stringify(weights)}` : "";
  console.log(`sensitivity: ${matches} matches per setup, quarters ${quarterSeconds}s, home +20 on one attribute v unchanged mirror${weightNote}`);
  const mirror = play(base);
  console.log(`mirror: home margin ${(mirror.margin / matches).toFixed(1)} (built-in home edge), home win ${(100 * mirror.win / matches).toFixed(0)}%`);
  for (const key of attributes) {
    const test = play(boosted(key));
    console.log(`\n+20 ${key}: margin ${(test.margin / matches).toFixed(1)}, win ${(100 * test.win / matches).toFixed(0)}%`);
    for (const [attr, label, value, kind, dir, lo, hi] of ROWS.filter((row) => row[0] === key)) {
      const a = value(mirror);
      const b = value(test);
      const delta = kind === "pts" ? b.v - a.v : 100 * (b.v / a.v - 1);
      const se = kind === "pts" && a.n && b.n ? 100 * Math.sqrt(Math.sqrt(a.v / 100 * (1 - a.v / 100) / a.n) ** 2 + Math.sqrt(b.v / 100 * (1 - b.v / 100) / b.n) ** 2) : null;
      const size = dir === 0 ? Math.abs(delta) : delta * dir;
      const verdict = size < lo ? "too weak" : size > hi ? "too strong" : "ok";
      const want = dir === 0 ? `within ±${hi}` : `${dir > 0 ? "+" : "-"}${lo}${hi !== lo ? "-" + hi : ""}`;
      console.log(`  ${label.padEnd(40)} ${a.v.toFixed(1).padStart(7)} -> ${b.v.toFixed(1).padStart(7)}  change ${(delta >= 0 ? "+" : "") + delta.toFixed(1)}${se === null ? "" : " ±" + se.toFixed(1)}  target ${want}  ${verdict}`);
    }
  }
}
if (process.argv[2] === "sensitivity") { await runSensitivity(process.argv.slice(3)); process.exit(0); }

const overrides = Object.fromEntries(args.filter((a) => a.includes("=")).map((a) => a.split("=")).map(([k, v]) => [k, Number(v)]));
for (const key of Object.keys(overrides)) if (!(key in DEFAULT_TUNING)) throw new Error(`unknown tuning key ${key}`);
const [matches = 12, firstSeed = 1] = args.filter((a) => !a.includes("=")).map(Number);
// Real clubs only: the data also holds a placeholder club ("-") and tiny lists that cannot field 18.
const clubCounts = players.reduce((map, player) => map.set(player.club, (map.get(player.club) ?? 0) + 1), new Map());
const clubs = [...clubCounts].filter(([club, count]) => club && club !== "-" && count >= 24).map(([club]) => club).sort();
const lineupFor = (club) => {
 const squad = players.filter((player) => player.club === club);
 const selected = createAssistantTeamSelection(squad).selectedSide;
 return Object.entries(selected).filter(([slot, name]) => name && !slot.startsWith("INT"))
 .map(([position, name]) => ({ position, player: squad.find((player) => player.name === name) }));
};
const lineups = Object.fromEntries(clubs.map((club) => [club, lineupFor(club)]));

const keys = ["disposals", "kicks", "handballs", "marks", "contestedMarks", "marksInside50", "contestedPossessions", "tackles", "inside50s", "rebound50s",
 "clearances", "turnovers", "intercepts", "onePercenters", "effectiveDisposals", "freeKicksFor", "hitouts", "goals", "behinds"];
const totals = Object.fromEntries(keys.map((key) => [key, 0]));
const typeCounts = {};
let teams = 0; let points = 0; let shots = 0; let margin = 0; let events = 0; let problems = 0; let ms = 0; let sq = 0; let nonScoring = 0;
for (let i = 0; i < matches; i += 1) {
 const home = clubs[(i * 2) % clubs.length];
 const away = clubs[(i * 2 + 1) % clubs.length];
 const started = Date.now();
 const result = simulateMatchEvents({ seed: firstSeed + i, tuning: overrides, home: { name: home, lineup: lineups[home] }, away: { name: away, lineup: lineups[away] } });
 ms += Date.now() - started;
 problems += verifyEventLog(result.events, { finalScore: result.score }).length;
 events += result.events.length;
 nonScoring += result.events.filter((e) => e.type === "SHOT" && (e.outcome === "MISS" || e.outcome === "SHORT")).length;
 for (const e of result.events) typeCounts[e.type] = (typeCounts[e.type] ?? 0) + 1;
 margin += Math.abs(result.score.home.total - result.score.away.total);
 for (const side of ["home", "away"]) {
 teams += 1;
 points += result.score[side].total;
 sq += result.score[side].total ** 2;
 shots += result.score[side].goals + result.score[side].behinds;
 for (const row of result.playerStats[side]) for (const key of keys) totals[key] += row[key] ?? 0;
 }
}
const per = (value) => (value / teams).toFixed(1);
const sd = Math.sqrt(sq / teams - (points / teams) ** 2);
const bench = { points: "85-95", disposals: "350-380", kicks: "230-250", handballs: "120-140", marks: "85-100", contestedMarks: "15-20", marksInside50: "10-14",
 contestedPossessions: "135-150", tackles: "55-65", inside50s: "50-58", rebound50s: "45-55", clearances: "36-42", intercepts: "50-60",
 freeKicksFor: "20-26", effectiveDisposals: "265-290", hitouts: "30-42", goals: "12-14", shots: "24-27" };
console.log(`${matches} matches, ${teams} team-games, ${(ms / matches).toFixed(0)} ms/match, ${(events / matches).toFixed(0)} events/match, log problems: ${problems}`);
console.log(`avg margin ${(margin / matches).toFixed(1)} (AFL ~28-32) team score sd ${sd.toFixed(1)} (AFL ~ 22-25) non-scoring shots/team ${(nonScoring / teams).toFixed(1)}`);
const rows = [["points", per(points)], ["shots", per(shots)], ...keys.map((key) => [key, per(totals[key])])];
for (const [name, value] of rows) console.log(`${name.padEnd(22)}${String(value).padStart(8)} ${bench[name] ? "AFL ~" + bench[name] : ""}`);
const perMatch = (type) => ((typeCounts[type] ?? 0) / matches).toFixed(0);
console.log(`per match: centre bounces ${perMatch("CENTRE_BOUNCE")}, ball-ups ${perMatch("BALL_UP")}, throw-ins ${perMatch("THROW_IN")}, kick-ins ${perMatch("KICK_IN")}, free kicks ${perMatch("FREE_KICK")}`);
console.log(`goal accuracy ${((totals.goals / Math.max(1, totals.goals + totals.behinds)) * 100).toFixed(0)}% AFL ~52-54%`);