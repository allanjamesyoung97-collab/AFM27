// Plays headless matches on the seeded engine and checks every event log against
// the match rulebook (src/engine/matchRules.js).
//
//   node tools/audit-match-rules.mjs            # 12 matches
//   node tools/audit-match-rules.mjs 40         # 40 matches
//   node tools/audit-match-rules.mjs 12 --show  # also print example violations
import { players } from "../src/data/players.js";
import { createAssistantTeamSelection } from "../src/engine/teamSelectionEngine.js";
import { simulateMatchEvents } from "../src/engine/matchSimEngine.js";
import { auditMatchRules } from "../src/engine/matchRules.js";

const matches = Number(process.argv[2]) > 0 ? Number(process.argv[2]) : 12;
const show = process.argv.includes("--show");
const clubs = ["Essendon", "Collingwood", "Geelong", "Sydney", "Brisbane", "Carlton", "Fremantle", "Hawthorn"];

const lineupFor = (club) => {
  const squad = players.filter((player) => player.club === club);
  const selected = createAssistantTeamSelection(squad).selectedSide;
  return Object.entries(selected).filter(([slot, name]) => name && !slot.startsWith("INT"))
    .map(([position, name]) => ({ position, player: squad.find((player) => player.name === name) }));
};

const totals = { events: 0, goals: 0, behinds: 0, outOfBounds: 0, throwIns: 0, ballUps: 0, kicks: 0, handballs: 0 };
const rules = {};
const examples = {};
for (let i = 0; i < matches; i += 1) {
  const home = clubs[i % clubs.length];
  const away = clubs[(i + 3) % clubs.length];
  const { events } = simulateMatchEvents({ seed: 1000 + i, home: { name: home, lineup: lineupFor(home) }, away: { name: away, lineup: lineupFor(away) } });
  const audit = auditMatchRules(events, { maxViolations: 1e9 });
  for (const [rule, count] of Object.entries(audit.counts)) rules[rule] = (rules[rule] ?? 0) + count;
  for (const v of audit.violations) (examples[v.rule] ??= []).length < 3 && examples[v.rule].push(`match ${i} #${v.seq}: ${v.message}`);
  totals.events += events.length;
  for (const e of events) {
    if (e.type === "SHOT" && e.outcome === "GOAL") totals.goals += 1;
    if (e.type === "SHOT" && e.outcome === "BEHIND") totals.behinds += 1;
    if (e.outcome === "OUT_OF_BOUNDS") totals.outOfBounds += 1;
    if (e.type === "THROW_IN") totals.throwIns += 1;
    if (e.type === "BALL_UP") totals.ballUps += 1;
    if (e.type === "KICK" || e.type === "KICK_IN") totals.kicks += 1;
    if (e.type === "HANDBALL") totals.handballs += 1;
  }
}

const per = (n) => (n / matches).toFixed(1);
console.log(`${matches} matches`);
console.log(`per match: goals ${per(totals.goals)}, behinds ${per(totals.behinds)}, kicks ${per(totals.kicks)}, handballs ${per(totals.handballs)}, out of bounds ${per(totals.outOfBounds)}, throw-ins ${per(totals.throwIns)}, ball-ups ${per(totals.ballUps)}`);
const names = Object.keys(rules);
if (!names.length) console.log("rule violations: none");
else {
  console.log("rule violations (total, per match):");
  for (const rule of names) console.log(`  ${rule.padEnd(30)} ${String(rules[rule]).padStart(6)}  ${per(rules[rule])}`);
  if (show) for (const [rule, list] of Object.entries(examples)) { console.log(`\n${rule}`); list.forEach((line) => console.log(`  ${line}`)); }
}
process.exitCode = names.length ? 1 : 0;