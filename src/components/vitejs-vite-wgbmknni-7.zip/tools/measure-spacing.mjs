// Measures how the field is spread around the ball at each possession action.
//   node tools/measure-spacing.mjs [matches=4] [firstSeed=1]
import { players } from "../src/data/players.js";
import { createAssistantTeamSelection } from "../src/engine/teamSelectionEngine.js";
import { buildMatchContext, createMatchState, stepMatch } from "../src/engine/matchSimEngine.js";
import { METRES_PER_X, METRES_PER_Y } from "../src/engine/matchPresentation.js";

const [matches = 4, firstSeed = 1] = process.argv.slice(2).map(Number);
const clubCounts = players.reduce((map, p) => map.set(p.club, (map.get(p.club) ?? 0) + 1), new Map());
const clubs = [...clubCounts].filter(([c, n]) => c && c !== "-" && n >= 24).map(([c]) => c).sort();
const lineupFor = (club) => {
  const squad = players.filter((p) => p.club === club);
  const sel = createAssistantTeamSelection(squad).selectedSide;
  return Object.entries(sel).filter(([s, n]) => n && !s.startsWith("INT")).map(([position, name]) => ({ position, player: squad.find((p) => p.name === name) }));
};
const m = (a, b) => Math.hypot((a.x - b.x) * METRES_PER_X, (a.y - b.y) * METRES_PER_Y);
const line = (slot) => (/^(FF|FP|FB|BP)/.test(slot) ? "pocket/key" : /^(HF|CHF)/.test(slot) ? "HF/CHF" : /^(HB|CHB)/.test(slot) ? "HB/CHB" : /^W/.test(slot) ? "wing" : "mid/ruck");

let steps = 0; let teammates16 = 0; let teammates30 = 0; let none16 = 0; let within20All = 0; let within40All = 0;
const lineDist = {}; const lineN = {};
for (let i = 0; i < matches; i += 1) {
  const home = clubs[(i * 2) % clubs.length]; const away = clubs[(i * 2 + 1) % clubs.length];
  const ctx = buildMatchContext({ home: { name: home, lineup: lineupFor(home) }, away: { name: away, lineup: lineupFor(away) } });
  let state = createMatchState({ seed: firstSeed + i, ctx });
  const slotOf = new Map(ctx.spatialEntries.map((e) => [String(e.player.id), e.slot]));
  const sideOf = new Map(ctx.spatialEntries.map((e) => [String(e.player.id), e.side]));
  while (state.status !== "FULL_TIME") {
    if (state.next.kind === "CARRY" && state.status === "LIVE") {
      const carrier = state.positions[String(state.next.carrierId)];
      if (carrier) {
        steps += 1;
        let t16 = 0; let t30 = 0; let all20 = 0; let all40 = 0;
        for (const [id, p] of Object.entries(state.positions)) {
          if (id === String(state.next.carrierId)) continue;
          const d = m(p, carrier);
          if (d <= 20) all20 += 1;
          if (d <= 40) all40 += 1;
          if (sideOf.get(id) === state.next.side) {
            if (d <= 16) t16 += 1;
            if (d <= 30) t30 += 1;
          }
          const key = `${line(slotOf.get(id))} (${sideOf.get(id) === state.next.side ? "carrier's side" : "opposition"})`;
          lineDist[key] = (lineDist[key] ?? 0) + d; lineN[key] = (lineN[key] ?? 0) + 1;
        }
        teammates16 += t16; teammates30 += t30; none16 += t16 === 0 ? 1 : 0; within20All += all20; within40All += all40;
      }
    }
    state = stepMatch(state, ctx).state;
  }
}
console.log(`${steps} possession actions`);
console.log(`teammates within 16 m (handball range): ${(teammates16 / steps).toFixed(2)}   actions with none: ${((none16 / steps) * 100).toFixed(0)}%`);
console.log(`teammates within 30 m: ${(teammates30 / steps).toFixed(2)}`);
console.log(`all players within 20 m: ${(within20All / steps).toFixed(1)}   within 40 m: ${(within40All / steps).toFixed(1)}  (of 35)`);
console.log("average distance from the ball carrier, by line:");
for (const key of Object.keys(lineDist).sort()) console.log(`  ${key.padEnd(32)}${(lineDist[key] / lineN[key]).toFixed(0).padStart(4)} m`);